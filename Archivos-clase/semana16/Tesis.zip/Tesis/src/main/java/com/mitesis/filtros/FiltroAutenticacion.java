package com.mitesis.filtros;

import com.mitesis.modelos.Usuario;
import java.io.IOException;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Filtro de seguridad que intercepta todas las peticiones.
 * Se asegura de que un usuario haya iniciado sesión antes de
 * acceder a las páginas protegidas (paneles de control).
 */
@WebFilter("/*") // Intercepta TODAS las peticiones
public class FiltroAutenticacion implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        HttpSession session = httpRequest.getSession(false);

        // Obtenemos la URL que el usuario está intentando visitar
        String requestURI = httpRequest.getRequestURI();
        String contextPath = httpRequest.getContextPath();

        boolean estaLogueado = (session != null && session.getAttribute("usuario") != null);
        
        // 1. Recursos que SIEMPRE se permiten (páginas de login, CSS, JS)
        boolean esPaginaLogin = requestURI.equals(contextPath + "/") || 
                                requestURI.equals(contextPath + "/index.jsp") || 
                                requestURI.equals(contextPath + "/LoginControlador");
        
        boolean esRecursoEstatico = requestURI.startsWith(contextPath + "/css/") ||
                                  requestURI.startsWith(contextPath + "/js/");

        if (esPaginaLogin || esRecursoEstatico) {
            // Dejar pasar (no necesita login)
            chain.doFilter(request, response);
        } else if (estaLogueado) {
            // 2. El usuario ESTÁ logueado
            
            // Verificación de ROL (¡Importante!)
            // Prevenir que un estudiante entre a /admin.jsp
            Usuario usuario = (Usuario) session.getAttribute("usuario");
            String rol = usuario.getRol();
            
            if ( (requestURI.contains("admin") && !rol.equals("admin")) ||
                 (requestURI.contains("docente") && !rol.equals("docente")) ||
                 (requestURI.contains("estudiante") && !rol.equals("estudiante")) ) 
            {
                // Rol incorrecto, lo mandamos al index (o a una página de "acceso denegado")
                httpResponse.sendRedirect(contextPath + "/index.jsp?error=AccesoDenegado");
            } else {
                // Rol correcto, dejar pasar
                chain.doFilter(request, response);
            }
            
        } else {
            // 3. El usuario NO está logueado y trata de acceder a algo protegido
            httpResponse.sendRedirect(contextPath + "/index.jsp?error=DebeIniciarSesion");
        }
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Método de inicialización (opcional)
    }

    @Override
    public void destroy() {
        // Método de destrucción (opcional)
    }
}