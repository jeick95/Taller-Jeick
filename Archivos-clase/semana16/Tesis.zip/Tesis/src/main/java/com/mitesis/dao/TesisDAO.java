package com.mitesis.dao;

import com.mitesis.modelos.Tesis;
import com.mitesis.modelos.HistorialEstado;
import com.mitesis.util.ConexionDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO (Data Access Object) para todas las operaciones
 * relacionadas con la tabla 'tesis'.
 */
public class TesisDAO {
    
    // Instancia del DAO de Historial para usar en las transacciones
    private HistorialEstadoDAO historialDAO = new HistorialEstadoDAO();

    /**
     * Obtiene la tesis de un estudiante específico.
     * (Asumimos que un estudiante solo puede tener una tesis activa a la vez).
     * @param idEstudianteAutor El ID del estudiante.
     * @return El objeto Tesis, o null si no tiene.
     */
    public Tesis obtenerTesisPorEstudiante(int idEstudianteAutor) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Tesis tesis = null;
        
        String sql = "SELECT * FROM tesis WHERE idEstudianteAutor = ?";

        try {
            conn = ConexionDB.getInstancia().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, idEstudianteAutor);
            rs = ps.executeQuery();

            if (rs.next()) {
                tesis = poblarTesisDesdeResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener tesis por estudiante: " + e.getMessage());
            e.printStackTrace();
        } finally {
            cerrarRecursos(conn, ps, rs);
        }
        return tesis;
    }

    /**
     * Obtiene una lista de todas las tesis asignadas a un docente.
     * @param idDocenteRevisor El ID del docente.
     * @return Una lista de objetos Tesis.
     */
    public List<Tesis> obtenerTesisPorDocente(int idDocenteRevisor) {
        List<Tesis> listaTesis = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        String sql = "SELECT * FROM tesis WHERE idDocenteRevisor = ? ORDER BY fechaProximaRevision ASC";

        try {
            conn = ConexionDB.getInstancia().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, idDocenteRevisor);
            rs = ps.executeQuery();

            while (rs.next()) {
                listaTesis.add(poblarTesisDesdeResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener tesis por docente: " + e.getMessage());
            e.printStackTrace();
        } finally {
            cerrarRecursos(conn, ps, rs);
        }
        return listaTesis;
    }
    
    public List<Tesis> obtenerTesisRevisadasPorDocente(int idDocenteRevisor) {
        List<Tesis> listaTesis = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        String sql = "SELECT * FROM tesis "
                   + "WHERE idDocenteRevisor = ? "
                   + "AND (estado = 'Aprobado' OR estado = 'Rechazado') "
                   + "ORDER BY fechaSubida DESC";

        try {
            conn = ConexionDB.getInstancia().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, idDocenteRevisor);
            rs = ps.executeQuery();

            while (rs.next()) {
                listaTesis.add(poblarTesisDesdeResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener tesis revisadas por docente: " + e.getMessage());
            e.printStackTrace();
        } finally {
            cerrarRecursos(conn, ps, rs);
        }
        return listaTesis;
    }
    
    /**
     * Obtiene una lista de todas las tesis que no tienen revisor asignado.
     * Usado por el Admin en "Asignar Revisiones".
     * @return Una lista de objetos Tesis.
     */
    public List<Tesis> obtenerTesisSinAsignar() {
        List<Tesis> listaTesis = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        String sql = "SELECT * FROM tesis WHERE idDocenteRevisor IS NULL AND estado = 'Pendiente'";

        try {
            conn = ConexionDB.getInstancia().getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                listaTesis.add(poblarTesisDesdeResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener tesis sin asignar: " + e.getMessage());
            e.printStackTrace();
        } finally {
            cerrarRecursos(conn, ps, rs);
        }
        return listaTesis;
    }
    
    // NOTA: Faltaría un método "obtenerTodasLasTesisConNombres" para el admin,
    // que use JOINs para traer el nombre del autor y revisor.

    /**
     * Asigna un revisor y una fecha límite a una tesis.
     * Esta operación es transaccional (actualiza Tesis y crea Historial).
     * @param idTesis El ID de la tesis a actualizar.
     * @param idDocenteRevisor El ID del docente a asignar.
     * @param fechaLimite La fecha límite para la revisión (puede ser null).
     * @param idAdmin El ID del admin que realiza la operación.
     * @return true si fue exitoso, false si no.
     */
    public boolean asignarRevisor(int idTesis, int idDocenteRevisor, java.sql.Date fechaLimite, int idAdmin) {
        Connection conn = null;
        PreparedStatement psTesis = null;
        boolean exito = false;
        
        String sql = "UPDATE tesis SET idDocenteRevisor = ?, fechaProximaRevision = ?, estado = 'En Revisión' WHERE idTesis = ?";

        try {
            conn = ConexionDB.getInstancia().getConnection();
            // 1. Iniciar Transacción
            conn.setAutoCommit(false);
            
            // 2. Actualizar la tabla 'tesis'
            psTesis = conn.prepareStatement(sql);
            psTesis.setInt(1, idDocenteRevisor);
            psTesis.setDate(2, fechaLimite);
            psTesis.setInt(3, idTesis);
            int filasTesis = psTesis.executeUpdate();

            // 3. Crear el registro en 'historial_estado'
            if (filasTesis > 0) {
                HistorialEstado historial = new HistorialEstado();
                historial.setIdTesis(idTesis);
                historial.setIdUsuarioModificador(idAdmin);
                historial.setEstadoNuevo("En Revisión");
                historial.setNotas("Tesis asignada a docente por administrador.");
                
                boolean exitoHistorial = historialDAO.crearHistorial(historial, conn);
                
                if (exitoHistorial) {
                    // 4. Si todo salió bien, confirmar
                    conn.commit();
                    exito = true;
                } else {
                    // 5. Si falló el historial, revertir
                    conn.rollback();
                }
            } else {
                conn.rollback(); // No se actualizó la tesis
            }

        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback(); // Revertir en caso de error SQL
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            System.err.println("Error al asignar revisor: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // 6. Cerrar recursos y restaurar auto-commit
            if (psTesis != null) {
                try {
                    psTesis.close();
                } catch (SQLException e) { e.printStackTrace(); }
            }
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) { e.printStackTrace(); }
            }
        }
        return exito;
    }
    
    // --- MÉTODOS DE UTILIDAD ---

    /**
     * Método helper para poblar un objeto Tesis desde un ResultSet.
     */
    private Tesis poblarTesisDesdeResultSet(ResultSet rs) throws SQLException {
        Tesis tesis = new Tesis();
        tesis.setIdTesis(rs.getInt("idTesis"));
        tesis.setTitulo(rs.getString("titulo"));
        tesis.setDescripcion(rs.getString("descripcion"));
        tesis.setFechaSubida(rs.getTimestamp("fechaSubida"));
        tesis.setEstado(rs.getString("estado"));
        tesis.setUrlArchivo(rs.getString("urlArchivo"));
        tesis.setFechaProximaRevision(rs.getDate("fechaProximaRevision"));
        tesis.setIdEstudianteAutor(rs.getInt("idEstudianteAutor"));
        tesis.setIdDocenteRevisor(rs.getInt("idDocenteRevisor"));
        return tesis;
    }

    /**
     * Cierra la conexión, PreparedStatement y ResultSet de forma segura.
     */
    private void cerrarRecursos(Connection conn, PreparedStatement ps, ResultSet rs) {
        try {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (conn != null) conn.close(); // Devuelve la conexión al pool
        } catch (SQLException e) {
            System.err.println("Error al cerrar recursos JDBC: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Obtiene TODAS las tesis con los nombres del autor y revisor.
     * Usa JOINs. Es para la tabla principal de "Gestión de Tesis" del Admin.
     * @return Una lista de objetos Tesis con los campos nombreAutor y nombreRevisor llenos.
     */
    public List<Tesis> obtenerTodasLasTesisDetallado() {
        List<Tesis> listaTesis = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        // SQL con JOINs para traer los nombres
        String sql = "SELECT t.*, "
                   + "CONCAT(u_aut.nombre, ' ', u_aut.apellido) AS nombreAutor, "
                   + "CONCAT(u_rev.nombre, ' ', u_rev.apellido) AS nombreRevisor "
                   + "FROM tesis t "
                   + "JOIN usuarios u_aut ON t.idEstudianteAutor = u_aut.idUsuario " // JOIN con autor
                   + "LEFT JOIN usuarios u_rev ON t.idDocenteRevisor = u_rev.idUsuario " // LEFT JOIN con revisor (puede ser NULL)
                   + "ORDER BY t.fechaSubida DESC";

        try {
            conn = ConexionDB.getInstancia().getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                // Usamos el helper normal
                Tesis tesis = poblarTesisDesdeResultSet(rs);
                
                // Llenamos los campos adicionales que trajimos con el JOIN
                tesis.setNombreAutor(rs.getString("nombreAutor"));
                tesis.setNombreRevisor(rs.getString("nombreRevisor")); // Será NULL si no hay revisor
                
                listaTesis.add(tesis);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener todas las tesis detallado: " + e.getMessage());
            e.printStackTrace();
        } finally {
            cerrarRecursos(conn, ps, rs);
        }
        return listaTesis;
    }
    
    /**
     * Actualiza el estado de una tesis (ej. "Aprobado", "Requiere Correcciones").
     * Esta operación es transaccional (actualiza Tesis y crea Historial).
     *
     * @param idTesis El ID de la tesis a actualizar.
     * @param idDocente El ID del docente que realiza la calificación.
     * @param nuevoEstado El nuevo estado a asignar.
     * @param notas Comentarios/notas de la revisión.
     * @return true si fue exitoso, false si no.
     * @throws SQLException
     */
    public boolean actualizarEstadoPorDocente(int idTesis, int idDocente, String nuevoEstado, String notas) throws SQLException {
        Connection conn = null;
        PreparedStatement psTesis = null;
        boolean exito = false;
        
        // Asumimos que la tabla 'tesis' tiene 'fechaUltimaRevision' o una columna similar
        String sql = "UPDATE tesis SET estado = ?, fechaUltimaRevision = NOW() WHERE idTesis = ? AND idDocenteRevisor = ?";

        try {
            conn = ConexionDB.getInstancia().getConnection();
            // 1. Iniciar Transacción
            conn.setAutoCommit(false);
            
            // 2. Actualizar la tabla 'tesis'
            psTesis = conn.prepareStatement(sql);
            psTesis.setString(1, nuevoEstado);
            psTesis.setInt(2, idTesis);
            psTesis.setInt(3, idDocente); // Seguridad: un docente solo puede calificar su tesis
            int filasTesis = psTesis.executeUpdate();

            // 3. Crear el registro en 'historial_estado'
            if (filasTesis > 0) {
                HistorialEstado historial = new HistorialEstado();
                historial.setIdTesis(idTesis);
                historial.setIdUsuarioModificador(idDocente); // El docente es quien modifica
                historial.setEstadoNuevo(nuevoEstado);
                historial.setNotas(notas);
                
                // Usamos la conexión transaccional (tu historialDAO ya lo soporta)
                boolean exitoHistorial = historialDAO.crearHistorial(historial, conn); 
                
                if (exitoHistorial) {
                    // 4. Si todo salió bien, confirmar
                    conn.commit();
                    exito = true;
                } else {
                    // 5. Si falló el historial, revertir
                    conn.rollback();
                }
            } else {
                conn.rollback(); // No se actualizó la tesis (quizás el ID o el IDDocente no coincidían)
            }

        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback(); // Revertir en caso de error SQL
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            System.err.println("Error al actualizar estado de tesis: " + e.getMessage());
            e.printStackTrace();
            throw e; // Re-lanzar la excepción
        } finally {
            // 6. Cerrar recursos y restaurar auto-commit
            if (psTesis != null) psTesis.close();
            if (conn != null) {
                conn.setAutoCommit(true);
                conn.close();
            }
        }
        return exito;
    }
    
    public boolean registrarEntrega(int idEstudiante, String tipoEntrega, String comentarios, String urlArchivo) {
    Connection conn = null;
    PreparedStatement ps = null;
    boolean exito = false;

    // Dependiendo de tu lógica, si es "Propuesta Inicial" quizás el estado es "Pendiente".
    // Si es "Correcciones", quizás pasa a "En Revisión".
    // Por simplicidad, lo dejaremos en "Pendiente" para que el Admin lo asigne.
    String sql = "UPDATE tesis SET urlArchivo = ?, fechaSubida = NOW(), descripcion = CONCAT(descripcion, ' | Nota: ', ?), estado = 'Pendiente' WHERE idEstudianteAutor = ?";

    try {
        conn = ConexionDB.getInstancia().getConnection();
        ps = conn.prepareStatement(sql);
        ps.setString(1, urlArchivo);
        ps.setString(2, comentarios); // Añadimos el comentario a la descripción (o podrías crear una tabla de entregas aparte)
        ps.setInt(3, idEstudiante);

        int filas = ps.executeUpdate();
        exito = filas > 0;

    } catch (SQLException e) {
        System.err.println("Error al registrar entrega: " + e.getMessage());
        e.printStackTrace();
    } finally {
        cerrarRecursos(conn, ps, null);
    }
    return exito;
}
    // --- Faltarían métodos como: ---
    // public boolean crearTesis(Tesis tesis, int idAdmin) { ... } (Transaccional, similar a asignarRevisor)
    // public boolean actualizarEstadoTesis(int idTesis, String nuevoEstado, int idDocente) { ... } (Transaccional)
    // public boolean eliminarTesis(int idTesis) { ... }
}