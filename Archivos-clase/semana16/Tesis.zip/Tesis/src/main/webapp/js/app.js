document.addEventListener('DOMContentLoaded', () => {
            
    // --- REFERENCIAS A LAS PANTALLAS ---
    const welcomeScreen = document.getElementById('welcome-screen');
    const loginScreen = document.getElementById('login-screen');
    // Dashboards
    const studentDashboard = document.getElementById('estudiante-dashboard');
    const teacherDashboard = document.getElementById('docente-dashboard');
    const adminDashboard = document.getElementById('admin-dashboard');
    // Sub-paginas
    const studentSubpage = document.getElementById('estudiante-subpage');
    const teacherSubpage = document.getElementById('docente-subpage');
    const adminSubpage = document.getElementById('admin-subpage');

    const allScreens = [
        welcomeScreen, loginScreen, 
        studentDashboard, teacherDashboard, adminDashboard,
        studentSubpage, teacherSubpage, adminSubpage
    ];

    // --- REFERENCIAS A LOS BOTONES ---
    // NOTA: 'comenzar-btn' eliminado.
    const loginBtns = document.querySelectorAll('.login-btn');
    const logoutBtns = document.querySelectorAll('.logout-btn');
    const dashboardCards = document.querySelectorAll('.dashboard-card'); 
    const backBtns = document.querySelectorAll('.back-btn');

    // --- LÓGICA DE MODO OSCURO ---
    const themeToggleBtns = document.querySelectorAll('.theme-toggle-btn');
    
    // Función para aplicar el tema
    function applyTheme(theme) {
        if (theme === 'dark') {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
    }

    // Cargar tema al inicio
    let currentTheme = localStorage.getItem('theme');
    if (!currentTheme) {
        currentTheme = 'dark'; // Default
    }
    applyTheme(currentTheme);
    
    themeToggleBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            // Prevenir comportamiento por defecto si está dentro de un form
            e.preventDefault(); 
            let nuevoTema;
            if (document.documentElement.classList.contains('dark')) {
                nuevoTema = 'light';
            } else {
                nuevoTema = 'dark';
            }
            localStorage.setItem('theme', nuevoTema);
            applyTheme(nuevoTema);
        });
    });


    // --- FUNCIÓN DE NAVEGACIÓN ---
    function navigateTo(screen) {
        // Ocultar todas las pantallas
        allScreens.forEach(s => {
            if (s) { 
                s.classList.add('hidden');
                s.classList.remove('animate-fade-in'); 
            }
        });
        
        // Mostrar la pantalla objetivo
        if (screen) {
            screen.classList.remove('hidden');
            screen.classList.add('animate-fade-in');
        }
    }

    // --- LÓGICA DE TRANSICIÓN AUTOMÁTICA (BIENVENIDA -> LOGIN) ---
    // Si existe la pantalla de bienvenida, esperar 1.5s y cambiar
    if (welcomeScreen) {
        setTimeout(() => {
            // Iniciar animación de salida
            welcomeScreen.classList.add('animate-fade-out');
            
            // Esperar a que termine la animación (0.5s en CSS) para cambiar
            welcomeScreen.addEventListener('animationend', () => {
                navigateTo(loginScreen);
                welcomeScreen.classList.remove('animate-fade-out'); // Limpieza
            }, { once: true });
            
        }, 1500); // 1500 milisegundos = 1.5 segundos
    }


    // --- RESTO DE LA LÓGICA DE INTERFAZ ---

    // Click en Botones de Login (Si usas botones demo, sino el form hace submit)
    loginBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const targetId = btn.dataset.target;
            const targetDashboard = document.getElementById(targetId);
            if (targetDashboard) {
                loginScreen.classList.add('animate-fade-out');
                loginScreen.addEventListener('animationend', () => {
                    navigateTo(targetDashboard);
                    loginScreen.classList.remove('animate-fade-out');
                }, { once: true });
            }
        });
    });

    // Click en "Cerrar Sesión" (Aunque ahora es un link <a>, esto sirve si usas button)
    logoutBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            // La navegación real la maneja el href del enlace hacia LogoutControlador
            // Esto es solo visual si quisieras animación antes de salir
            const currentDashboard = btn.closest('section');
            if (currentDashboard) {
                currentDashboard.classList.add('animate-fade-out');
            }
        });
    });

    // Click en Tarjetas del Panel (o enlaces de la barra lateral)
    dashboardCards.forEach(card => {
        card.addEventListener('click', (e) => {
            
            // Si es un enlace real (ej. Logout), no prevenimos el default
            if(card.getAttribute('href') && card.getAttribute('href').includes('Logout')) return;

            // Si tiene data-target-page, es navegación interna SPA
            if (card.dataset.targetPage) {
                e.preventDefault(); 
                const currentDashboard = card.closest('section[id$="-dashboard"]');
                let mainDashboard;

                if (currentDashboard) {
                    mainDashboard = currentDashboard;
                } else {
                    const subpageSection = card.closest('section[id$="-subpage"]');
                    if (!subpageSection) return;
                    if (subpageSection.id.includes('estudiante')) mainDashboard = studentDashboard;
                    else if (subpageSection.id.includes('docente')) mainDashboard = teacherDashboard;
                    else if (subpageSection.id.includes('admin')) mainDashboard = adminDashboard;
                }

                const targetPageId = card.dataset.targetPage;
                const targetPage = document.getElementById(targetPageId);
                const templateId = card.dataset.templateId;
                const template = document.getElementById(templateId);

                if (targetPage && template) {
                    const title = card.dataset.title;
                    const titleEl = targetPage.querySelector('h1[id^="subpage-title-"]');
                    const contentEl = targetPage.querySelector('div[id^="subpage-content-"]');
                    
                    if (titleEl) titleEl.textContent = title;
                    if (contentEl) {
                        contentEl.innerHTML = ''; 
                        contentEl.appendChild(template.content.cloneNode(true));
                    }
                }

                if (targetPage) {
                    if (mainDashboard) {
                        const mainContent = mainDashboard.querySelector('.flex-1.p-8.overflow-y-auto');
                        if (mainContent) mainContent.classList.add('hidden');
                    }

                    if (!targetPage.classList.contains('hidden')) return; 
                    
                    const currentSection = card.closest('section');
                    currentSection.classList.add('animate-fade-out');
                    currentSection.addEventListener('animationend', () => {
                        navigateTo(targetPage); 
                        currentSection.classList.remove('animate-fade-out');
                        currentSection.classList.add('hidden'); 
                    }, { once: true });
                }
            }
        });
    });

    // Click en "Volver"
    backBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const targetDashboardId = btn.dataset.targetDashboard;
            const targetDashboard = document.getElementById(targetDashboardId);
            const currentSubpage = btn.closest('section');

            if (targetDashboard) {
                const mainContent = targetDashboard.querySelector('.flex-1.p-8.overflow-y-auto');
                if (mainContent) mainContent.classList.remove('hidden');

                currentSubpage.classList.add('animate-fade-out');
                currentSubpage.addEventListener('animationend', () => {
                    navigateTo(targetDashboard); 
                    currentSubpage.classList.remove('animate-fade-out');
                }, { once: true });
            }
        });
    });

    // Modal (Lógica simple para cerrar)
    const alertModal = document.getElementById('alert-modal');
    const alertCloseBtn = document.getElementById('alert-modal-close');
    if(alertCloseBtn && alertModal) {
        alertCloseBtn.addEventListener('click', () => {
            alertModal.classList.add('hidden');
        });
    }

});