<%-- 
    Document   : estudiante
    Created on : 16 nov 2025
    Author     : Jefferson
    Versión    : Conectado a MVC (Dinámico) - Corregido
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%-- PASO 1: Descomentamos la librería de JSTL (Jakarta Standard Tag Library) --%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Módulo de Estudiante</title>
    
    <script src="https://cdn.tailwindcss.com"></script>    
    <script>
      tailwind.config = { darkMode: 'class' }
    </script>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/main.css">
    
</head>
<body class="antialiased text-slate-800 bg-white dark:bg-slate-900 dark:text-slate-200" data-context-path="${pageContext.request.contextPath}">

    <main>

        <section id="estudiante-dashboard" class="h-screen w-full flex flex-row bg-blue-50 dark:bg-slate-800">
            
            <nav class="w-72 bg-white dark:bg-slate-900 shadow-lg p-6 flex flex-col flex-shrink-0 overflow-y-auto">
                
                <div class="flex flex-col items-center text-center mb-8 space-y-4">
                    <div class="p-2 bg-blue-50 dark:bg-slate-800 rounded-full mb-2">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-10 h-10 text-blue-600 dark:text-blue-400">
                             <path stroke-linecap="round" stroke-linejoin="round" d="M4.26 10.147a60.436 60.436 0 0 0-.491 6.347A48.627 48.627 0 0 1 12 20.904a48.627 48.627 0 0 1 8.232-4.41 60.46 60.46 0 0 0-.491-6.347m-15.482 0a50.57 50.57 0 0 0-2.658-.813A59.905 59.905 0 0 1 12 3.493a59.902 59.902 0 0 1 10.499 5.221 50.57 50.57 0 0 0-2.658.814m-15.482 0A50.697 50.697 0 0 1 12 13.489a50.702 50.702 0 0 1 7.74-3.342M6.75 15a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5zm0 0v-3.675A55.378 55.378 0 0 1 12 8.443m-7.007 11.55A5.981 5.981 0 0 0 6.75 15.75v-1.5" />
                        </svg>
                    </div>
                    
                    <%-- CORRECCIÓN: Nombres de propiedades según Usuario.java --%>
                    <img src="${sessionScope.usuario.fotoPerfilUrl}" alt="Foto de Perfil" class="w-20 h-20 rounded-full ring-4 ring-blue-50 dark:ring-slate-800" onerror="this.onerror=null;this.src='https://placehold.co/100x100/2563eb/FFFFFF?text=Estudiante';">
                    <div>
                        <h2 class="text-lg font-bold text-slate-800 dark:text-slate-200">${sessionScope.usuario.nombre} ${sessionScope.usuario.apellido}</h2>
                        <p class="text-sm font-medium text-blue-600 dark:text-blue-400">${sessionScope.usuario.carrera}</p>
                        <span class="inline-block mt-1 px-2 py-1 text-xs font-semibold text-blue-800 bg-blue-100 rounded-full dark:bg-blue-900 dark:text-blue-200">Estudiante</span>
                    </div>
                </div>
                
                <div class="flex-1 space-y-1">
                    <h3 class="text-xs font-semibold text-slate-400 dark:text-slate-500 uppercase mb-2 px-2">Mi Tesis</h3>
                    <a class="dashboard-card sidebar-link w-full flex items-center px-4 py-3 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-blue-50 dark:hover:bg-slate-800 hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer transition-colors"
                       data-target-page="estudiante-subpage" data-title="Mi Tesis" data-template-id="template-est-mi-tesis">
                       Mi Tesis
                    </a>
                    <a class="dashboard-card sidebar-link w-full flex items-center px-4 py-3 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-blue-50 dark:hover:bg-slate-800 hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer transition-colors"
                       data-target-page="estudiante-subpage" data-title="Subir Archivos" data-template-id="template-est-subir">
                       Subir Archivos
                    </a>
                    <a class="dashboard-card sidebar-link w-full flex items-center px-4 py-3 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-blue-50 dark:hover:bg-slate-800 hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer transition-colors"
                       data-target-page="estudiante-subpage" data-title="Mi Asesor" data-template-id="template-est-mi-asesor">
                       Mi Asesor
                    </a>
                    
                    <h3 class="text-xs font-semibold text-slate-400 dark:text-slate-500 uppercase mt-6 mb-2 px-2">Organización</h3>
                    <a class="dashboard-card sidebar-link w-full flex items-center px-4 py-3 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-blue-50 dark:hover:bg-slate-800 hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer transition-colors"
                       data-target-page="estudiante-subpage" data-title="Calendario" data-template-id="template-est-calendario">
                       Calendario
                    </a>
                    <a class="dashboard-card sidebar-link w-full flex items-center px-4 py-3 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-blue-50 dark:hover:bg-slate-800 hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer transition-colors"
                       data-target-page="estudiante-subpage" data-title="Mensajería" data-template-id="template-est-mensajes">
                       Mensajería
                    </a>
                    
                    <h3 class="text-xs font-semibold text-slate-400 dark:text-slate-500 uppercase mt-6 mb-2 px-2">Cuenta</h3>
                    <a class="dashboard-card sidebar-link w-full flex items-center px-4 py-3 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-blue-50 dark:hover:bg-slate-800 hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer transition-colors"
                       data-target-page="estudiante-subpage" data-title="Configuración" data-template-id="template-est-configuracion">
                       Configuración
                    </a>
                </div>
            </nav>
            
            <div class="flex-1 flex flex-col h-screen">
                <header class="bg-white dark:bg-slate-900 shadow-md p-4 flex justify-between items-center">
                    <h1 class="text-2xl font-bold text-blue-700 dark:text-blue-300">Panel del Estudiante</h1>
                    <div class="flex items-center space-x-2">
                        <button class="theme-toggle-btn p-2 rounded-full text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800 transition-colors">
                            <svg class="theme-icon-sun w-6 h-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 3v2.25m6.364.386-1.591 1.591M21 12h-2.25m-.386 6.364-1.591-1.591M12 18.75V21m-6.364-.386 1.591-1.591M3 12H.75m.386-6.364 1.591 1.591" /></svg>
                            <svg class="theme-icon-moon w-6 h-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M21.752 15.002A9.72 9.72 0 0 1 18 15.75c-5.385 0-9.75-4.365-9.75-9.75 0-1.33.266-2.597.748-3.752A9.753 9.753 0 0 0 3 11.25c0 5.385 4.365 9.75 9.75 9.75 2.671 0 5.1-1.057 6.9-2.798Z" /></svg>
                        </button>
                        
                        <a href="${pageContext.request.contextPath}/LogoutControlador" 
                           class="p-2 rounded-full text-slate-500 hover:text-red-600 hover:bg-red-100 dark:text-slate-400 dark:hover:bg-red-200 dark:hover:text-red-700 transition-colors" 
                           title="Cerrar Sesión">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6a2.25 2.25 0 0 0-2.25 2.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15M15.75 9l-3.375 3.375M15.75 9h6.75m-6.75 0-3.375-3.375" /></svg>                            
                        </a>
                    </div>
                </header>
                
                <div class="flex-1 p-8 overflow-y-auto">
                    
                    <%-- Bloque para mostrar notificaciones --%>
                    <c:if test="${not empty sessionScope.exito}">
                        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
                            <strong class="font-bold">¡Éxito!</strong>
                            <span class="block sm:inline">${sessionScope.exito}</span>
                        </div>
                        <c:remove var="exito" scope="session"/>
                    </c:if>

                    <c:if test="${not empty sessionScope.error}">
                        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                            <strong class="font-bold">Error:</strong>
                            <span class="block sm:inline">${sessionScope.error}</span>
                        </div>
                        <c:remove var="error" scope="session"/>
                    </c:if>

                    <%-- CORRECCIÓN: Saludo dinámico --%>
                    <h2 class="text-3xl font-bold text-slate-800 dark:text-slate-100 mb-8 animate-fade-in" style="animation-delay: 0.1s;">
                        Bienvenido, ${sessionScope.usuario.nombre} 
                    </h2>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fade-in" style="animation-delay: 0.2s;">
                        
                        <div class="dashboard-card bg-white dark:bg-slate-800 p-6 rounded-lg shadow-md flex items-center space-x-4 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors" data-target-page="estudiante-subpage" data-title="Mi Tesis" data-template-id="template-est-mi-tesis">
                            <div class="p-3 rounded-full bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-300">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-8 h-8">
                                  <path stroke-linecap="round" stroke-linejoin="round" d="M12 6.042A8.967 8.967 0 0 0 6 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 0 1 6 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 0 1 6-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0 0 18 18a8.967 8.967 0 0 0-6 2.292m0-14.25v14.25" />
                                </svg>
                            </div>
                            <div>
                                <p class="text-sm font-medium text-slate-500 dark:text-slate-400">Estado de Tesis</p>
                                <c:choose>
                                    <c:when test="${not empty miTesis.estado}">
                                        <span class="px-2 inline-flex text-sm leading-5 font-semibold rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                                            ${miTesis.estado}
                                        </span>
                                    </c:when>
                                    <c:otherwise>
                                        <span class="px-2 inline-flex text-sm leading-5 font-semibold rounded-full bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200">
                                            Sin Tesis
                                        </span>
                                    </c:otherwise>
                                </c:choose>
                            </div>
                        </div>

                        <div class="dashboard-card bg-white dark:bg-slate-800 p-6 rounded-lg shadow-md flex items-center space-x-4 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors" data-target-page="estudiante-subpage" data-title="Calendario" data-template-id="template-est-calendario">
                            <div class="p-3 rounded-full bg-yellow-100 text-yellow-600 dark:bg-yellow-900 dark:text-yellow-300">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-8 h-8"><path stroke-linecap="round" stroke-linejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 0 1 2.25-2.25h13.5A2.25 2.25 0 0 1 21 7.5v11.25m-18 0A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75m-18 0v-7.5A2.25 2.25 0 0 1 5.25 9h13.5A2.25 2.25 0 0 1 21 11.25v7.5" /></svg>
                            </div>
                            <div>
                                <p class="text-sm font-medium text-slate-500 dark:text-slate-400">Próxima Entrega</p>
                                <c:choose>
                                    <c:when test="${not empty eventos[0]}">
                                        <p class="text-lg font-bold text-slate-800 dark:text-slate-100">${eventos[0].titulo}</p>
                                    </c:when>
                                    <c:otherwise>
                                        <p class="text-lg font-bold text-slate-800 dark:text-slate-100">Sin eventos</p>
                                    </c:otherwise>
                                </c:choose>
                            </div>
                        </div>
                        
                        <div class="dashboard-card bg-white dark:bg-slate-800 p-6 rounded-lg shadow-md flex items-center space-x-4 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors" data-target-page="estudiante-subpage" data-title="Mensajería" data-template-id="template-est-mensajes">
                            <div class="p-3 rounded-full bg-green-100 text-green-600 dark:bg-green-900 dark:text-green-300">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-8 h-8"><path stroke-linecap="round" stroke-linejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 0 1-2.25 2.25h-15a2.25 2.25 0 0 1-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25m19.5 0v.243a2.25 2.25 0 0 1-1.07 1.916l-7.5 4.615a2.25 2.25 0 0 1-2.36 0L3.32 8.91a2.25 2.25 0 0 1-1.07-1.916V6.75" /></svg>
                            </div>
                            <div>
                                <p class="text-sm font-medium text-slate-500 dark:text-slate-400">Mensajes del Asesor</p>
                                <c:choose>
                                    <c:when test="${mensajesNoLeidosCount == 1}">
                                        <p class="text-lg font-bold text-red-700 dark:text-red-400">1 sin leer</p>
                                    </c:when>
                                    <c:when test="${mensajesNoLeidosCount > 1}">
                                        <p class="text-lg font-bold text-red-700 dark:text-red-400">${mensajesNoLeidosCount} sin leer</p>
                                    </c:when>
                                    <c:otherwise>
                                        <p class="text-lg font-bold text-slate-800 dark:text-slate-100">0 sin leer</p>
                                    </c:otherwise>
                                </c:choose>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </section>

        <section id="estudiante-subpage" class="h-screen w-full flex flex-row hidden bg-blue-50 dark:bg-slate-800">
            
            <nav class="w-72 bg-white dark:bg-slate-900 shadow-lg p-6 flex flex-col flex-shrink-0 overflow-y-auto">
                
                <div class="flex flex-col items-center text-center mb-8 space-y-4">
                    <div class="p-2 bg-blue-50 dark:bg-slate-800 rounded-full mb-2">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-10 h-10 text-blue-600 dark:text-blue-400">
                             <path stroke-linecap="round" stroke-linejoin="round" d="M4.26 10.147a60.436 60.436 0 0 0-.491 6.347A48.627 48.627 0 0 1 12 20.904a48.627 48.627 0 0 1 8.232-4.41 60.46 60.46 0 0 0-.491-6.347m-15.482 0a50.57 50.57 0 0 0-2.658-.813A59.905 59.905 0 0 1 12 3.493a59.902 59.902 0 0 1 10.499 5.221 50.57 50.57 0 0 0-2.658.814m-15.482 0A50.697 50.697 0 0 1 12 13.489a50.702 50.702 0 0 1 7.74-3.342M6.75 15a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5zm0 0v-3.675A55.378 55.378 0 0 1 12 8.443m-7.007 11.55A5.981 5.981 0 0 0 6.75 15.75v-1.5" />
                        </svg>
                    </div>
                    
                    <%-- CORRECCIÓN: Nombres de propiedades aquí también --%>
                    <img src="${sessionScope.usuario.fotoPerfilUrl}" alt="Foto de Perfil" class="w-20 h-20 rounded-full ring-4 ring-blue-50 dark:ring-slate-800" onerror="this.onerror=null;this.src='https://placehold.co/100x100/2563eb/FFFFFF?text=Estudiante';">
                    <div>
                        <h2 class="text-lg font-bold text-slate-800 dark:text-slate-200">${sessionScope.usuario.nombre} ${sessionScope.usuario.apellido}</h2>
                        <p class="text-sm font-medium text-blue-600 dark:text-blue-400">${sessionScope.usuario.carrera}</p>
                        <span class="inline-block mt-1 px-2 py-1 text-xs font-semibold text-blue-800 bg-blue-100 rounded-full dark:bg-blue-900 dark:text-blue-200">Estudiante</span>
                    </div>
                </div>
                
                <div class="flex-1 space-y-1">
                    <h3 class="text-xs font-semibold text-slate-400 dark:text-slate-500 uppercase mb-2 px-2">Mi Tesis</h3>
                    <a class="dashboard-card sidebar-link w-full flex items-center px-4 py-3 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-blue-50 dark:hover:bg-slate-800 hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer transition-colors"
                       data-target-page="estudiante-subpage" data-title="Mi Tesis" data-template-id="template-est-mi-tesis">
                       Mi Tesis
                    </a>
                    <a class="dashboard-card sidebar-link w-full flex items-center px-4 py-3 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-blue-50 dark:hover:bg-slate-800 hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer transition-colors"
                       data-target-page="estudiante-subpage" data-title="Subir Archivos" data-template-id="template-est-subir">
                       Subir Archivos
                    </a>
                    <a class="dashboard-card sidebar-link w-full flex items-center px-4 py-3 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-blue-50 dark:hover:bg-slate-800 hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer transition-colors"
                       data-target-page="estudiante-subpage" data-title="Mi Asesor" data-template-id="template-est-mi-asesor">
                       Mi Asesor
                    </a>
                    
                    <h3 class="text-xs font-semibold text-slate-400 dark:text-slate-500 uppercase mt-6 mb-2 px-2">Organización</h3>
                    <a class="dashboard-card sidebar-link w-full flex items-center px-4 py-3 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-blue-50 dark:hover:bg-slate-800 hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer transition-colors"
                       data-target-page="estudiante-subpage" data-title="Calendario" data-template-id="template-est-calendario">
                       Calendario
                    </a>
                    <a class="dashboard-card sidebar-link w-full flex items-center px-4 py-3 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-blue-50 dark:hover:bg-slate-800 hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer transition-colors"
                       data-target-page="estudiante-subpage" data-title="Mensajería" data-template-id="template-est-mensajes">
                       Mensajería
                    </a>
                    
                    <h3 class="text-xs font-semibold text-slate-400 dark:text-slate-500 uppercase mt-6 mb-2 px-2">Cuenta</h3>
                    <a class="dashboard-card sidebar-link w-full flex items-center px-4 py-3 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-blue-50 dark:hover:bg-slate-800 hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer transition-colors"
                       data-target-page="estudiante-subpage" data-title="Configuración" data-template-id="template-est-configuracion">
                       Configuración
                    </a>
                </div>
            </nav>

            <div class="flex-1 flex flex-col h-screen">
                <header class="bg-white dark:bg-slate-900 shadow-md p-4 flex justify-between items-center">
                    <button class="back-btn btn-fill" data-target-dashboard="estudiante-dashboard" style="border-radius: 8px; padding: 0.5rem 1rem; font-size: 0.9rem;">
                        &larr; Volver
                    </button>
                    <h1 id="subpage-title-estudiante" class="text-2xl font-bold text-blue-700 dark:text-blue-300"></h1>
                    <div class="flex items-center space-x-2">
                        <button class="theme-toggle-btn p-2 rounded-full text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800 transition-colors">
                            <svg class="theme-icon-sun w-6 h-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 3v2.25m6.364.386-1.591 1.591M21 12h-2.25m-.386 6.364-1.591-1.591M12 18.75V21m-6.364-.386 1.591-1.591M3 12H.75m.386-6.364 1.591 1.591" /></svg>
                            <svg class="theme-icon-moon w-6 h-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M21.752 15.002A9.72 9.72 0 0 1 18 15.75c-5.385 0-9.75-4.365-9.75-9.75 0-1.33.266-2.597.748-3.752A9.753 9.753 0 0 0 3 11.25c0 5.385 4.365 9.75 9.75 9.75 2.671 0 5.1-1.057 6.9-2.798Z" /></svg>
                        </button>
                        
                        <a href="${pageContext.request.contextPath}/LogoutControlador" 
                           class="p-2 rounded-full text-slate-500 hover:text-red-600 hover:bg-red-100 dark:text-slate-400 dark:hover:bg-red-200 dark:hover:text-red-700 transition-colors" 
                           title="Cerrar Sesión">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6a2.25 2.25 0 0 0-2.25 2.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15M15.75 9l-3.375 3.375M15.75 9h6.75m-6.75 0-3.375-3.375" /></svg>                            
                        </a>
                    </div>
                </header>
                <div id="subpage-content-estudiante" class="flex-1 p-8 overflow-y-auto">
                    <p>Cargando contenido...</p>
                </div>
            </div>
        </section>

    </main>
    
    <div id="alert-modal" class="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 hidden" style="animation-duration: 0.3s;">
        <div class="bg-white dark:bg-slate-800 rounded-lg shadow-2xl p-6 max-w-sm w-full animate-fade-in" style="animation-duration: 0.3s;">
            <h3 id="alert-modal-title" class="text-lg font-bold text-slate-900 dark:text-white mb-4">Aviso</h3>
            <p id="alert-modal-message" class="text-slate-600 dark:text-slate-300 mb-6">Mensaje de alerta.</p>
            <button id="alert-modal-close" class="btn-fill-solid w-full" style="background-color: #3b82f6; border-color: #3b82f6;">Entendido</button>
        </div>
    </div>
    
    <div id="content-templates" class="hidden">

        <%-- Plantilla: Mi Tesis (Dinámica) --%>
        <template id="template-est-mi-tesis">
            <c:if test="${not empty miTesis}">
                <div class="bg-white dark:bg-slate-800 p-8 rounded-lg shadow-md animate-fade-in" style="animation-delay: 0.1s;">
                    <h3 class="text-2xl font-semibold text-slate-800 dark:text-slate-100 mb-6">Estado de mi Tesis</h3>
                    <div class="space-y-4 mb-8">
                        <div>
                            <h4 class="text-sm font-semibold text-slate-500 dark:text-slate-400">TÍTULO</h4>
                            <p class="text-lg text-slate-800 dark:text-slate-200">${miTesis.titulo}</p>
                        </div>
                        <div>
                            <h4 class="text-sm font-semibold text-slate-500 dark:text-slate-400">ASESOR</h4>
                            <%-- CORRECCIÓN: NombreRevisor viene de Tesis.java --%>
                            <p class="text-lg text-slate-800 dark:text-slate-200">${miTesis.nombreRevisor}</p>
                        </div>
                        <div>
                            <h4 class="text-sm font-semibold text-slate-500 dark:text-slate-400">ESTADO ACTUAL</h4>
                            <span class="px-3 py-1 inline-flex text-base leading-5 font-semibold rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                                ${miTesis.estado}
                            </span>
                        </div>
                    </div>
                    
                    <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-100 mb-4">Historial de Revisiones</h4>
                    <ol class="relative border-l border-slate-200 dark:border-slate-700 space-y-6">
                        <%-- TODO: Agregar lógica para listar historial real desde el controlador si es necesario --%>
                        <li class="ml-4">
                            <span class="absolute flex items-center justify-center w-6 h-6 bg-blue-100 rounded-full -left-3 ring-8 ring-white dark:ring-slate-900 dark:bg-blue-900">
                                <svg aria-hidden="true" class="w-3 h-3 text-blue-800 dark:text-blue-300" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"></path></svg>
                            </span>
                            <h3 class="flex items-center text-base font-semibold text-slate-900 dark:text-white">Registro inicial</h3>
                            <time class="block mb-2 text-sm font-normal leading-none text-slate-400 dark:text-slate-500">${miTesis.fechaSubida}</time>
                            <p class="text-base font-normal text-slate-500 dark:text-slate-400">${miTesis.descripcion}</p>
                        </li>
                    </ol>
                </div>
            </c:if>
            <c:if test="${empty miTesis}">
                <div class="bg-white dark:bg-slate-800 p-8 rounded-lg shadow-md animate-fade-in">
                    <h3 class="text-2xl font-semibold text-slate-800 dark:text-slate-100 mb-6">Sin Tesis Registrada</h3>
                    <p class="text-slate-600 dark:text-slate-300">
                        Aún no tienes una tesis registrada en el sistema. 
                        Por favor, ve a la sección "Subir Archivos" para enviar tu propuesta inicial.
                    </p>
                </div>
            </c:if>
        </template>
        
        <%-- Plantilla: Subir Archivos --%>
        <template id="template-est-subir">
            <div class="bg-white dark:bg-slate-800 p-8 rounded-lg shadow-md animate-fade-in" style="animation-delay: 0.1s;">
                <h3 class="text-2xl font-semibold text-slate-800 dark:text-slate-100 mb-6">Subir Archivos</h3>
                
                <form class="space-y-6 max-w-lg" 
                      action="${pageContext.request.contextPath}/dashboardEstudiante" 
                      method="POST" 
                      enctype="multipart/form-data">
                      
                    <input type="hidden" name="accion" value="subirArchivo">
                    
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Tipo de Entrega</label>
                        <select name="tipoEntrega" class="w-full px-4 py-3 rounded-lg border border-slate-300 bg-white dark:bg-slate-700 dark:border-slate-600 dark:text-white outline-none focus:ring-2 focus:ring-blue-500">
                            <option value="Propuesta Inicial">Propuesta Inicial</option>
                            <option value="Correcciones">Correcciones (Revisión)</option>
                            <option value="Documento Final">Documento Final</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Archivo (PDF, DOCX)</label>
                        <input type="file" name="archivo" class="w-full px-4 py-3 rounded-lg border border-slate-300 bg-white dark:bg-slate-700 dark:border-slate-600 dark:text-white outline-none focus:ring-2 focus:ring-blue-500"/>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Comentarios para el Asesor (Opcional)</label>
                        <textarea name="comentarios" rows="4" class="w-full px-4 py-3 rounded-lg border border-slate-300 bg-white dark:bg-slate-700 dark:border-slate-600 dark:text-white outline-none focus:ring-2 focus:ring-blue-500" placeholder="Describe los cambios realizados..."></textarea>
                    </div>
                    <button type="submit" class="btn-fill-solid" style="background-color: #2563eb; border-color: #2563eb;">Enviar Archivo</button>
                </form>
            </div>
        </template>
        
        <%-- Plantilla: Mi Asesor --%>
        <template id="template-est-mi-asesor">
            <c:if test="${not empty miTesis.nombreRevisor}">
                <div class="bg-white dark:bg-slate-800 p-8 rounded-lg shadow-md animate-fade-in" style="animation-delay: 0.1s;">
                    <h3 class="text-2xl font-semibold text-slate-800 dark:text-slate-100 mb-6">Mi Asesor</h3>
                    <div class="flex items-center space-x-6">
                        <img src="https://placehold.co/100x100/16a34a/FFFFFF?text=Docente" alt="Foto de Perfil" class="w-24 h-24 rounded-full ring-4 ring-green-100 dark:ring-green-900">
                        <div>
                            <h2 class="text-2xl font-bold text-slate-800 dark:text-slate-200">${miTesis.nombreRevisor}</h2>
                            <p class="text-lg font-medium text-green-600 dark:text-green-400">Docente Revisor</p>
                            <button class="btn-fill mt-4 dashboard-card" data-target-page="estudiante-subpage" data-title="Mensajería" data-template-id="template-est-mensajes" style="border-color: #2563eb; color: #2563eb;">
                                Contactar
                            </button>
                        </div>
                    </div>
                </div>
            </c:if>
            <c:if test="${empty miTesis.nombreRevisor}">
                 <div class="bg-white dark:bg-slate-800 p-8 rounded-lg shadow-md animate-fade-in">
                    <h3 class="text-2xl font-semibold text-slate-800 dark:text-slate-100 mb-6">Sin Asesor</h3>
                    <p class="text-slate-600 dark:text-slate-300">Aún no tienes un asesor asignado.</p>
                </div>
            </c:if>
        </template>
        
        <%-- Plantilla: Configuración --%>
        <template id="template-est-configuracion">
            <div class="bg-white dark:bg-slate-800 p-8 rounded-lg shadow-md animate-fade-in" style="animation-delay: 0.1s;">
                <h3 class="text-2xl font-semibold text-slate-800 dark:text-slate-100 mb-6">Configuración de Perfil</h3>
                <form class="space-y-6 max-w-lg" action="${pageContext.request.contextPath}/dashboardEstudiante" method="POST">
                    <input type="hidden" name="accion" value="actualizarPerfil">
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Nombre Completo</label>
                        <%-- CORRECCIÓN: Propiedades --%>
                        <input type="text" class="w-full px-4 py-3 rounded-lg border border-slate-300 bg-slate-100 dark:bg-slate-700 dark:border-slate-600 dark:text-slate-300 outline-none cursor-not-allowed" value="${sessionScope.usuario.nombre} ${sessionScope.usuario.apellido}" readonly>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Correo Electrónico</label>
                        <input type="email" name="email" class="w-full px-4 py-3 rounded-lg border border-slate-300 bg-white dark:bg-slate-700 dark:border-slate-600 dark:text-white outline-none focus:ring-2 focus:ring-blue-500" value="${sessionScope.usuario.email}">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Nueva Contraseña</label>
                        <input type="password" name="nuevaClave" class="w-full px-4 py-3 rounded-lg border border-slate-300 bg-white dark:bg-slate-700 dark:border-slate-600 dark:text-white outline-none focus:ring-2 focus:ring-blue-500" placeholder="••••••••">
                    </div>
                    <button type="submit" class="btn-fill-solid" style="background-color: #2563eb; border-color: #2563eb;">Guardar Cambios</button>
                </form>
            </div>
        </template>

        <%-- Plantilla: Calendario --%>
        <template id="template-est-calendario">
            <div class="bg-white dark:bg-slate-800 p-8 rounded-lg shadow-md animate-fade-in" style="animation-delay: 0.1s;">
                <h3 class="text-2xl font-semibold text-slate-800 dark:text-slate-100 mb-6">Calendario Académico</h3>
                <ul class="divide-y divide-slate-200 dark:divide-slate-700">
                    <c:forEach var="evento" items="${eventos}">
                        <li class="py-4">
                            <c:set var="color" value="text-blue-600 dark:text-blue-400" />
                            <c:if test="${evento.tipo == 'Entrega Límite'}">
                                <c:set var="color" value="text-red-600 dark:text-red-400" />
                            </c:if>
                            
                            <strong class="${color}">${evento.fechaEvento}:</strong> ${evento.titulo}
                        </li>
                    </c:forEach>
                    <c:if test="${empty eventos}">
                        <li class="py-4 text-slate-500">No hay eventos programados.</li>
                    </c:if>
                </ul>
            </div>
        </template>

        <%-- Plantilla: Mensajes --%>
        <template id="template-est-mensajes">
            <div class="bg-white dark:bg-slate-800 rounded-lg shadow-md animate-fade-in" style="animation-delay: 0.1s; overflow: hidden;">
                <h3 class="text-2xl font-semibold text-slate-800 dark:text-slate-100 mb-6 p-8 pb-0">Mensajería</h3>
                <div class="flex flex-col h-[500px]">
                    <div class="flex-1 p-8 space-y-4 overflow-y-auto bg-slate-50 dark:bg-slate-900">
                        
                        <c:forEach var="msg" items="${mensajes}">
                            <c:choose>
                                <%-- Mensaje ENVIADO (nuestro) --%>
                                <c:when test="${msg.idRemitente == sessionScope.usuario.idUsuario}">
                                    <div class="flex justify-end">
                                        <div class="p-3 rounded-lg bg-blue-600 dark:bg-blue-500 text-white max-w-xs">
                                            <p class="text-sm">${msg.cuerpo}</p>
                                            <time class="text-xs text-blue-100 mt-1 block">Tú</time>
                                        </div>
                                    </div>
                                </c:when>
                                <%-- Mensaje RECIBIDO --%>
                                <c:otherwise>
                                    <div class="flex">
                                        <div class="p-3 rounded-lg bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 max-w-xs text-slate-800 dark:text-slate-200">
                                            <p class="text-sm">${msg.cuerpo}</p>
                                            <time class="text-xs text-slate-400 mt-1 block">Asesor</time>
                                        </div>
                                    </div>
                                </c:otherwise>
                            </c:choose>
                        </c:forEach>
                        <c:if test="${empty mensajes}">
                            <p class="text-center text-slate-500 mt-10">No hay mensajes.</p>
                        </c:if>

                    </div>
                    <div class="p-4 bg-white dark:bg-slate-800 border-t dark:border-slate-700">
                        <form action="${pageContext.request.contextPath}/dashboardEstudiante" method="POST" class="flex space-x-2">
                             <input type="hidden" name="accion" value="enviarMensaje">
                             <input type="hidden" name="destinatarioId" value="${miTesis.idDocenteRevisor}"> 
                             <input type="text" name="contenido" placeholder="Escribe tu mensaje..." class="w-full px-4 py-2 rounded-lg border border-slate-300 dark:bg-slate-700 dark:border-slate-600 dark:text-white outline-none focus:ring-2 focus:ring-blue-500">
                             <button type="submit" class="btn-fill-solid" style="background-color: #2563eb; border-color: #2563eb; padding: 0.5rem 1.5rem;">Enviar</button>
                        </form>
                    </div>
                </div>
            </div>
        </template>

    </div> 
    
    <script src="${pageContext.request.contextPath}/js/app.js"></script>
    
</body>
</html>