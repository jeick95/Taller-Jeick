<%-- 
    Document   : index
    Created on : 16 nov 2025
    Author     : Jefferson
    Versión    : Animación Automática (1.5s)
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%-- CORRECTO PARA JAKARTA EE 10 / TOMCAT 10+ --%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Login Interactivo</title>
    
    <script src="https://cdn.tailwindcss.com"></script> 
    <script>
      tailwind.config = { 
        theme: {
          extend: {
            animation: {
              'float': 'float 3s ease-in-out infinite',
            },
            keyframes: {
              float: {
                '0%, 100%': { transform: 'translateY(0)' },
                '50%': { transform: 'translateY(-8px)' },
              }
            }
          }
        }
      }
    </script>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/main.css">
    <style>
        body {
            font-family: 'Inter', sans-serif;
        }
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
        }
        .card-shadow {
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15), 0 5px 20px rgba(0, 0, 0, 0.08);
        }
        .glass-effect {
            background: rgba(255, 255, 255, 0.12);
            backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        .input-focus-effect:focus {
            box-shadow: 0 0 0 3px rgba(255, 255, 255, 0.2);
            border-color: rgba(255, 255, 255, 0.4);
        }
        .image-container {
            position: relative;
            overflow: hidden;
            border-radius: 20px;
        }
        .image-container img {
            transition: transform 5s ease;
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .image-container:hover img {
            transform: scale(1.05);
        }
        .social-icon {
            transition: all 0.3s ease;
        }
        .social-icon:hover {
            transform: translateY(-3px);
        }
        .login-card {
            display: flex;
            flex-direction: column;
            min-height: 600px;
        }
        @media (min-width: 1024px) {
            .login-card {
                flex-direction: row;
            }
        }
        .overlay-content {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background: linear-gradient(to top, rgba(0, 0, 0, 0.8), transparent);
            padding: 1.5rem;
            color: white;
        }
        .user-card {
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 12px;
            padding: 0.875rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .user-card:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-2px);
        }
        .divider {
            height: 1px;
            background: linear-gradient(to right, transparent, rgba(255, 255, 255, 0.3), transparent);
            margin: 1.5rem 0;
        }
        .btn-glow {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            transition: all 0.3s ease;
        }
        .btn-glow:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(255, 255, 255, 0.15);
        }
        .form-input {
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.08);
        }
        .form-input:hover {
            background: rgba(255, 255, 255, 0.12);
        }
        .text-glow {
            text-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
        }
        
        /* Logo UPLA Styles */
        .logo-container {
            background: linear-gradient(135deg, #ffffff 0%, rgba(255, 255, 255, 0.9) 100%);
            border-radius: 50%;
            padding: 0.5rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        .logo-container:hover {
            transform: scale(1.05);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15);
        }
        .logo-img {
            border-radius: 50%;
            object-fit: cover;
            width: 100%;
            height: 100%;
        }
        
        /* Animación de puntos de carga */
        .loading-dots {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .loading-dots div {
            width: 8px;
            height: 8px;
            margin: 0 4px;
            border-radius: 50%;
            background-color: white;
            animation: bounce 1.4s infinite ease-in-out both;
        }
        .loading-dots div:nth-child(1) {
            animation-delay: -0.32s;
        }
        .loading-dots div:nth-child(2) {
            animation-delay: -0.16s;
        }
        @keyframes bounce {
            0%, 80%, 100% { transform: scale(0); }
            40% { transform: scale(1.0); }
        }
        
        /* Animación fadeIn personalizada */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        .animate-fade-in {
            animation: fadeIn 0.8s ease-in;
        }
    </style>
</head>
<body class="antialiased text-gray-800 bg-white" data-context-path="${pageContext.request.contextPath}">

    <main>

        <%-- PANTALLA DE BIENVENIDA (SPLASH SCREEN) --%>
        <section id="welcome-screen" class="h-screen w-full flex flex-col items-center justify-center p-8 gradient-bg text-white">
            
            <div class="animate-fade-in mb-8 text-center" style="animation-delay: 0.1s;">
                <!-- LOGO UPLA - PANTALLA DE BIENVENIDA -->
                <div class="mb-8">
                    <div class="w-48 h-48 mx-auto logo-container flex items-center justify-center p-4 animate-float">
                        <img src="${pageContext.request.contextPath}/logo-upla.png" 
                             alt="Logo UPLA - Universidad Peruana Los Andes" 
                             class="logo-img"
                             onerror="this.src='https://imgs.deperu.com/colegios/universidad_peruana_los_andes_logo.jpg'">
                    </div>
                </div>
                
                <h1 class="text-5xl md:text-6xl font-bold mb-4 animate-fade-in" style="animation-delay: 0.2s;">
                    Bienvenido
                </h1>
                <p class="text-xl opacity-90 mb-2 animate-fade-in" style="animation-delay: 0.4s;">
                    Universidad Peruana Los Andes
                </p>
                <p class="text-lg opacity-80 animate-fade-in" style="animation-delay: 0.6s;">
                    Ingresa tus credenciales para continuar
                </p>
            </div>

            <!-- Indicador de carga -->
            <div class="animate-fade-in mt-12" style="animation-delay: 1s;">
                <div class="loading-dots">
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
                <p class="text-white/70 text-sm mt-4 animate-pulse">Cargando sistema...</p>
            </div>
            
        </section>

        <%-- PANTALLA DE LOGIN --%>
        <section id="login-screen" class="h-screen w-full flex items-center justify-center p-6 gradient-bg hidden">
            
            <%-- CONTENEDOR PRINCIPAL DEL LOGIN --%>
            <div class="w-full max-w-5xl glass-effect rounded-2xl shadow-2xl overflow-hidden card-shadow animate-fade-in login-card">
                
                <%-- LADO IZQUIERDO: FORMULARIO DE LOGIN --%>
                <div class="w-full lg:w-1/2 p-8 md:p-10">
                    <!-- LOGO UPLA - ENCABEZADO DEL LOGIN -->
                    <div class="flex justify-center mb-6">
                        <div class="w-28 h-28 logo-container flex items-center justify-center p-3">
                            <img src="${pageContext.request.contextPath}/logo-upla.png" 
                                 alt="Logo UPLA" 
                                 class="logo-img"
                                 onerror="this.src='https://imgs.deperu.com/colegios/universidad_peruana_los_andes_logo.jpg'">
                        </div>
                    </div>

                    <h2 class="text-3xl font-bold text-white mb-2 text-center text-glow">Iniciar Sesión</h2>
                    <p class="text-white/80 mb-8 text-center">Accede con tu usuario y contraseña</p>
                    
                    <form action="${pageContext.request.contextPath}/LoginControlador" method="POST" class="space-y-6">                        
                        <div>
                            <label for="username" class="block text-sm font-semibold text-white mb-2">Usuario</label>
                            <input type="text" id="username" name="username"
                                   class="w-full px-4 py-3 rounded-lg border border-white/30 form-input text-white placeholder-white/50 input-focus-effect focus:outline-none transition-all duration-200"
                                   placeholder="admin" required>
                        </div>
                        
                        <div>
                            <label for="password" class="block text-sm font-semibold text-white mb-2">Contraseña</label>
                            <input type="password" id="password" name="password"
                                   class="w-full px-4 py-3 rounded-lg border border-white/30 form-input text-white placeholder-white/50 input-focus-effect focus:outline-none transition-all duration-200"
                                   placeholder="••••••••" required>
                        </div>

                        <%-- Alerta de errores de Login --%>
                        <c:if test="${not empty error}">
                            <div class="p-4 text-sm text-red-300 bg-red-500/20 rounded-lg border border-red-500/30" role="alert">
                                ${error}
                            </div>
                        </c:if>
                        <%-- Alerta de errores de Sesión (Filtro) --%>
                        <c:if test="${param.error eq 'DebeIniciarSesion'}">
                             <div class="p-4 text-sm text-yellow-300 bg-yellow-500/20 rounded-lg border border-yellow-500/30" role="alert">
                                Su sesión ha expirado o no ha iniciado sesión.
                            </div>
                        </c:if>
                        <c:if test="${param.error eq 'AccesoDenegado'}">
                             <div class="p-4 text-sm text-red-300 bg-red-500/20 rounded-lg border border-red-500/30" role="alert">
                                No tiene permisos para acceder a esa sección.
                            </div>
                        </c:if>

                        <button type="submit" class="w-full py-3 px-6 btn-glow text-purple-700 hover:text-purple-800 font-bold rounded-lg shadow-lg transition-all duration-300 flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5 mr-2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l-3 3m0 0l3 3m-3-3h12.75" />
                            </svg>
                            Ingresar
                        </button>
                        
                    </form>

                    <div class="divider"></div>

                    <%-- ACCESO RÁPIDO --%>
                    <div>
                        <h4 class="text-lg font-bold text-white mb-4 text-center text-glow">Acceso Rápido</h4>
                        
                        <div class="grid grid-cols-3 gap-3">
                            <div class="user-card" onclick="fillCredentials('estudiante', '123')">
                                <div class="text-center">
                                    <div class="text-lg font-bold text-white mb-1">Estudiante</div>
                                    <div class="text-sm text-white/80">estudiante/123</div>
                                </div>
                            </div>
                            
                            <div class="user-card" onclick="fillCredentials('docente', '123')">
                                <div class="text-center">
                                    <div class="text-lg font-bold text-white mb-1">Docente</div>
                                    <div class="text-sm text-white/80">docente/123</div>
                                </div>
                            </div>
                            
                            <div class="user-card" onclick="fillCredentials('admin', '123')">
                                <div class="text-center">
                                    <div class="text-lg font-bold text-white mb-1">Admin</div>
                                    <div class="text-sm text-white/80">admin/123</div>
                                </div>
                            </div>
                        </div>
                        
                        <p class="text-xs text-white/60 mt-4 text-center">(Haz clic en cualquier rol para rellenar automáticamente)</p>
                    </div>
                </div>

                <%-- LADO DERECHO: IMAGEN CON CONTENIDO --%>
                <div class="w-full lg:w-1/2 relative">
                    <div class="image-container h-full">
                        <img src="https://media.tenor.com/i8W2165dGc4AAAAM/library-reading.gif" 
                             alt="Educación y Tecnología">
                        
                        <div class="overlay-content">
                            <%-- CONTENIDO SUPERPUESTO --%>
                            <div class="mb-4">
                                <h3 class="text-sm font-bold uppercase tracking-wider text-white/90 mb-1">Universidad Peruana Los Andes</h3>
                                <p class="text-white/90 text-sm">
                                    Plataforma académica para gestión educativa y seguimiento de actividades.
                                </p>
                            </div>

                            <%-- REDES SOCIALES --%>
                            <div class="mt-4 pt-4 border-t border-white/20">
                                <div class="flex justify-center space-x-4">
                                    <a href="https://github.com" target="_blank" class="social-icon text-white hover:text-gray-300" title="GitHub">
                                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                                            <path fill-rule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" clip-rule="evenodd" />
                                        </svg>
                                    </a>
                                    
                                    <a href="https://facebook.com" target="_blank" class="social-icon text-white hover:text-blue-400" title="Facebook">
                                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                                            <path fill-rule="evenodd" d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" clip-rule="evenodd" />
                                        </svg>
                                    </a>
                                    
                                    <a href="https://youtube.com" target="_blank" class="social-icon text-white hover:text-red-500" title="YouTube">
                                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                                            <path fill-rule="evenodd" d="M19.812 5.418c.861.23 1.538.907 1.768 1.768C21.998 8.746 22 12 22 12s0 3.255-.418 4.814a2.504 2.504 0 0 1-1.768 1.768c-1.56.419-7.814.419-7.814.419s-6.255 0-7.814-.419a2.505 2.505 0 0 1-1.768-1.768C2 15.255 2 12 2 12s0-3.255.417-4.814a2.507 2.507 0 0 1 1.768-1.768C5.744 5 11.998 5 11.998 5s6.255 0 7.814.418ZM15.194 12 10 15V9l5.194 3Z" clip-rule="evenodd" />
                                        </svg>
                                    </a>
                                    
                                    <a href="https://linkedin.com" target="_blank" class="social-icon text-white hover:text-blue-700" title="LinkedIn">
                                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                                            <path fill-rule="evenodd" d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" clip-rule="evenodd" />
                                        </svg>
                                    </a>
                                    
                                    <a href="https://twitter.com" target="_blank" class="social-icon text-white hover:text-blue-400" title="Twitter/X">
                                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                                            <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </section>
        
    </main>
    
    <%-- Modal --%>
    <div id="alert-modal" class="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 hidden" style="animation-duration: 0.3s;">
        <div class="bg-white rounded-lg shadow-2xl p-6 max-w-sm w-full animate-fade-in" style="animation-duration: 0.3s;">
            <h3 id="alert-modal-title" class="text-lg font-bold text-slate-900 mb-4">Aviso</h3>
            <p id="alert-modal-message" class="text-slate-600 mb-6">Mensaje de alerta.</p>
            <button id="alert-modal-close" class="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-colors">
                Entendido
            </button>
        </div>
    </div>
    
    <script>
        // Función para llenar automáticamente las credenciales
        function fillCredentials(username, password) {
            document.getElementById('username').value = username;
            document.getElementById('password').value = password;
            
            // Mostrar notificación
            showAlert('Credenciales cargadas', `Usuario: \${username}\nContraseña: \${password}`, 'info');
        }
        
        // Función para mostrar alertas
        function showAlert(title, message, type = 'info') {
            const modal = document.getElementById('alert-modal');
            const modalTitle = document.getElementById('alert-modal-title');
            const modalMessage = document.getElementById('alert-modal-message');
            
            modalTitle.textContent = title;
            modalMessage.textContent = message;
            
            // Cambiar color según tipo
            const closeBtn = document.getElementById('alert-modal-close');
            if (type === 'info') {
                closeBtn.style.backgroundColor = '#3b82f6';
            } else if (type === 'success') {
                closeBtn.style.backgroundColor = '#10b981';
            }
            
            modal.classList.remove('hidden');
            
            // Cerrar modal
            document.getElementById('alert-modal-close').onclick = function() {
                modal.classList.add('hidden');
            };
            
            // Cerrar al hacer clic fuera
            modal.onclick = function(e) {
                if (e.target === modal) {
                    modal.classList.add('hidden');
                }
            };
        }
        
        // Animación automática de pantalla de bienvenida
        setTimeout(() => {
            document.getElementById('welcome-screen').classList.add('hidden');
            document.getElementById('login-screen').classList.remove('hidden');
        }, 2500);
    </script>

</body>
</html>