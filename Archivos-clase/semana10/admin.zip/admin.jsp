<%-- 
    Document   : admin
    Created on : 16 nov 2025
    Author     : Jefferson
    Versión    : Conectado a MVC (Dinámico) - Funcionalidades completas
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.functions" prefix="fn" %>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Módulo de Administrador</title>
    
    <script src="https://cdn.tailwindcss.com"></script>    
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        .animate-fade-in { animation: fadeIn 0.5s ease-out forwards; opacity: 0; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .btn-fill { background: transparent; border: 1px solid #64748b; color: #64748b; padding: 0.75rem 1.5rem; border-radius: 8px; font-weight: 600; transition: all 0.3s; cursor: pointer; }
        .btn-fill:hover { background: #64748b; color: white; }
        .btn-fill-solid { background: #3b82f6; border: 1px solid #3b82f6; color: white; padding: 0.75rem 1.5rem; border-radius: 8px; font-weight: 600; transition: all 0.3s; cursor: pointer; }
        .btn-fill-solid:hover { background: #2563eb; border-color: #2563eb; }
        .dashboard-card { transition: transform 0.3s, box-shadow 0.3s; }
        .dashboard-card:hover { transform: translateY(-4px); box-shadow: 0 10px 25px rgba(0,0,0,0.1); }
        .sidebar-link.active { background-color: #e2e8f0; color: #1e293b; font-weight: 600; }
        .btn-danger { background: #dc2626; border: 1px solid #dc2626; color: white; }
        .btn-danger:hover { background: #b91c1c; border-color: #b91c1c; }
        .btn-success { background: #059669; border: 1px solid #059669; color: white; }
        .btn-success:hover { background: #047857; border-color: #047857; }
    </style>
</head>
<body class="antialiased text-slate-800 bg-white" data-context-path="${pageContext.request.contextPath}">

    <main>

        <section id="admin-dashboard" class="h-screen w-full flex flex-row bg-slate-50">
            
            <nav class="w-72 bg-white shadow-lg p-6 flex flex-col flex-shrink-0 overflow-y-auto">
                
                <div class="flex flex-col items-center text-center mb-8 space-y-4">
                    <div class="p-2 bg-slate-100 rounded-full mb-2">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-10 h-10 text-slate-600">
                          <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12c0 1.268-.63 2.39-1.593 3.068a3.745 3.745 0 01-1.043 3.296 3.745 3.745 0 01-3.296 1.043A3.745 3.745 0 0112 21c-1.268 0-2.39-.63-3.068-1.593a3.746 3.746 0 01-3.296-1.043 3.745 3.745 0 01-1.043-3.296A3.745 3.745 0 013 12c0-1.268.63-2.39 1.593-3.068a3.745 3.745 0 011.043-3.296 3.746 3.746 0 013.296-1.043A3.746 3.746 0 0112 3c1.268 0 2.39.63 3.068 1.593a3.746 3.746 0 013.296 1.043 3.746 3.746 0 011.043 3.296A3.745 3.745 0 0121 12z" />
                        </svg>
                    </div>
                    
                    <img src="${sessionScope.usuario.fotoPerfilUrl}" alt="Foto de Perfil" class="w-20 h-20 rounded-full ring-4 ring-slate-200" onerror="this.onerror=null;this.src='https://placehold.co/100x100/64748b/FFFFFF?text=Admin';">
                    <div>
                        <h2 class="text-lg font-bold text-slate-800">${sessionScope.usuario.nombre} ${sessionScope.usuario.apellido}</h2>
                        <p class="text-sm font-medium text-slate-500">Oficina de Grados y Títulos</p>
                         <span class="inline-block mt-1 px-2 py-1 text-xs font-semibold text-slate-800 bg-slate-200 rounded-full">Administrador</span>
                    </div>
                </div>
                
                <div class="flex-1 space-y-1">
                    <h3 class="text-xs font-semibold text-slate-400 uppercase mb-2 px-2">Gestión</h3>
                    <a class="dashboard-card sidebar-link w-full flex items-center px-4 py-3 rounded-lg text-slate-600 hover:bg-slate-100 cursor-pointer transition-colors"
                       data-target-page="admin-subpage" data-title="Gestión de Tesis" data-template-id="template-admin-gestion-tesis">
                       Gestión de Tesis
                    </a>
                    <a class="dashboard-card sidebar-link w-full flex items-center px-4 py-3 rounded-lg text-slate-600 hover:bg-slate-100 cursor-pointer transition-colors"
                       data-target-page="admin-subpage" data-title="Usuarios" data-template-id="template-admin-gestion-usuarios">
                       Usuarios
                    </a>
                    <a class="dashboard-card sidebar-link w-full flex items-center px-4 py-3 rounded-lg text-slate-600 hover:bg-slate-100 cursor-pointer transition-colors"
                       data-target-page="admin-subpage" data-title="Asignar Revisiones" data-template-id="template-admin-asignar">
                       Asignar Revisiones
                    </a>
                    
                    <h3 class="text-xs font-semibold text-slate-400 uppercase mt-6 mb-2 px-2">Sistema</h3>
                    <a class="dashboard-card sidebar-link w-full flex items-center px-4 py-3 rounded-lg text-slate-600 hover:bg-slate-100 cursor-pointer transition-colors"
                       data-target-page="admin-subpage" data-title="Estadísticas" data-template-id="template-admin-estadisticas">
                       Estadísticas
                    </a>
                    <a class="dashboard-card sidebar-link w-full flex items-center px-4 py-3 rounded-lg text-slate-600 hover:bg-slate-100 cursor-pointer transition-colors"
                       data-target-page="admin-subpage" data-title="Reportes" data-template-id="template-admin-reportes">
                       Reportes
                    </a>
                    <a class="dashboard-card sidebar-link w-full flex items-center px-4 py-3 rounded-lg text-slate-600 hover:bg-slate-100 cursor-pointer transition-colors"
                       data-target-page="admin-subpage" data-title="Configuración" data-template-id="template-admin-configuracion">
                       Configuración
                    </a>
                </div>
            </nav>
            
            <div class="flex-1 flex flex-col h-screen">
                <header class="bg-white shadow-md p-4 flex justify-between items-center">
                    <h1 class="text-2xl font-bold text-slate-700">Panel de Administrador</h1>
                    <div class="flex items-center space-x-2">
                        <a href="${pageContext.request.contextPath}/LogoutControlador" 
                           class="p-2 rounded-full text-slate-500 hover:text-red-600 hover:bg-red-100 transition-colors" 
                           title="Cerrar Sesión">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6a2.25 2.25 0 0 0-2.25 2.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15M15.75 9l-3.375 3.375M15.75 9h6.75m-6.75 0-3.375-3.375" /></svg>                            
                        </a>
                    </div>
                </header>
                
                <div class="flex-1 p-8 overflow-y-auto">
                    
                    <h2 class="text-3xl font-bold text-slate-800 mb-8 animate-fade-in" style="animation-delay: 0.1s;">
                        Bienvenido, ${sessionScope.usuario.nombre}
                    </h2>

                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 animate-fade-in" style="animation-delay: 0.2s;">
                        
                        <div class="dashboard-card bg-white p-6 rounded-lg shadow-md cursor-pointer hover:bg-slate-50 transition-colors" data-target-page="admin-subpage" data-title="Gestión de Tesis" data-template-id="template-admin-gestion-tesis">
                            <div class="p-3 rounded-full bg-blue-100 text-blue-600 w-12 h-12 flex items-center justify-center mb-4">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" /></svg>
                            </div>
                            <div>
                                <p class="text-sm font-medium text-slate-500">Tesis en Sistema</p>
                                <p class="text-2xl font-bold text-slate-800">${totalTesis}</p>
                            </div>
                        </div>

                        <div class="dashboard-card bg-white p-6 rounded-lg shadow-md cursor-pointer hover:bg-slate-50 transition-colors" data-target-page="admin-subpage" data-title="Usuarios" data-template-id="template-admin-gestion-usuarios">
                            <div class="p-3 rounded-full bg-green-100 text-green-600 w-12 h-12 flex items-center justify-center mb-4">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6"><path stroke-linecap="round" stroke-linejoin="round" d="M15 19.128a9.38 9.38 0 0 0 2.625.372 9.337 9.337 0 0 0 4.121-.952 4.125 4.125 0 0 0-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 0 1 8.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0 1 11.964-3.07M12 6.375a3.375 3.375 0 1 1-6.75 0 3.375 3.375 0 0 1 6.75 0Zm8.25 2.25a2.625 2.625 0 1 1-5.25 0 2.625 2.625 0 0 1 5.25 0Z" /></svg>
                            </div>
                            <div>
                                <p class="text-sm font-medium text-slate-500">Usuarios Activos</p>
                                <p class="text-2xl font-bold text-slate-800">${totalUsuariosActivos}</p>
                            </div>
                        </div>

                        <div class="dashboard-card bg-white p-6 rounded-lg shadow-md cursor-pointer hover:bg-slate-50 transition-colors" data-target-page="admin-subpage" data-title="Asignar Revisiones" data-template-id="template-admin-asignar">
                            <div class="p-3 rounded-full bg-yellow-100 text-yellow-600 w-12 h-12 flex items-center justify-center mb-4">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z" /></svg>
                            </div>
                            <div>
                                <p class="text-sm font-medium text-slate-500">Tesis Sin Asignar</p>
                                <p class="text-2xl font-bold text-yellow-700">${fn:length(tesisSinAsignar)}</p>
                            </div>
                        </div>
                        
                        <div class="dashboard-card bg-white p-6 rounded-lg shadow-md cursor-pointer hover:bg-slate-50 transition-colors" data-target-page="admin-subpage" data-title="Reportes" data-template-id="template-admin-reportes">
                            <div class="p-3 rounded-full bg-purple-100 text-purple-600 w-12 h-12 flex items-center justify-center mb-4">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" /></svg>
                            </div>
                            <div>
                                <p class="text-sm font-medium text-slate-500">Reportes</p>
                                <span class="text-base font-bold text-purple-700">Ver Opciones</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id="admin-subpage" class="h-screen w-full flex flex-row hidden bg-slate-50">
            <nav class="w-72 bg-white shadow-lg p-6 flex flex-col flex-shrink-0 overflow-y-auto">
                 <div class="flex flex-col items-center text-center mb-8 space-y-4">
                     <img src="${sessionScope.usuario.fotoPerfilUrl}" alt="Foto de Perfil" class="w-20 h-20 rounded-full ring-4 ring-slate-200" onerror="this.onerror=null;this.src='https://placehold.co/100x100/64748b/FFFFFF?text=Admin';">
                     <div>
                         <h2 class="text-lg font-bold text-slate-800">${sessionScope.usuario.nombre} ${sessionScope.usuario.apellido}</h2>
                         <p class="text-sm font-medium text-slate-500">Oficina de Grados y Títulos</p>
                         <span class="inline-block mt-1 px-2 py-1 text-xs font-semibold text-slate-800 bg-slate-200 rounded-full">Administrador</span>
                     </div>
                 </div>
                 
                 <div class="flex-1 space-y-1">
                    <h3 class="text-xs font-semibold text-slate-400 uppercase mb-2 px-2">Gestión</h3>
                    <a class="dashboard-card sidebar-link w-full flex items-center px-4 py-3 rounded-lg text-slate-600 hover:bg-slate-100 cursor-pointer transition-colors"
                       data-target-page="admin-subpage" data-title="Gestión de Tesis" data-template-id="template-admin-gestion-tesis">
                       Gestión de Tesis
                    </a>
                    <a class="dashboard-card sidebar-link w-full flex items-center px-4 py-3 rounded-lg text-slate-600 hover:bg-slate-100 cursor-pointer transition-colors"
                       data-target-page="admin-subpage" data-title="Usuarios" data-template-id="template-admin-gestion-usuarios">
                       Usuarios
                    </a>
                    <a class="dashboard-card sidebar-link w-full flex items-center px-4 py-3 rounded-lg text-slate-600 hover:bg-slate-100 cursor-pointer transition-colors"
                       data-target-page="admin-subpage" data-title="Asignar Revisiones" data-template-id="template-admin-asignar">
                       Asignar Revisiones
                    </a>
                    
                    <h3 class="text-xs font-semibold text-slate-400 uppercase mt-6 mb-2 px-2">Sistema</h3>
                    <a class="dashboard-card sidebar-link w-full flex items-center px-4 py-3 rounded-lg text-slate-600 hover:bg-slate-100 cursor-pointer transition-colors"
                       data-target-page="admin-subpage" data-title="Estadísticas" data-template-id="template-admin-estadisticas">
                       Estadísticas
                    </a>
                    <a class="dashboard-card sidebar-link w-full flex items-center px-4 py-3 rounded-lg text-slate-600 hover:bg-slate-100 cursor-pointer transition-colors"
                       data-target-page="admin-subpage" data-title="Reportes" data-template-id="template-admin-reportes">
                       Reportes
                    </a>
                    <a class="dashboard-card sidebar-link w-full flex items-center px-4 py-3 rounded-lg text-slate-600 hover:bg-slate-100 cursor-pointer transition-colors"
                       data-target-page="admin-subpage" data-title="Configuración" data-template-id="template-admin-configuracion">
                       Configuración
                    </a>
                </div>
            </nav>

            <div class="flex-1 flex flex-col h-screen">
                <header class="bg-white shadow-md p-4 flex justify-between items-center">
                    <button class="back-btn btn-fill" data-target-dashboard="admin-dashboard" style="border-radius: 8px; padding: 0.5rem 1rem; font-size: 0.9rem;">
                        &larr; Volver
                    </button>
                    <h1 id="subpage-title-admin" class="text-2xl font-bold text-slate-700"></h1>
                    <div class="flex items-center space-x-2">
                        <a href="${pageContext.request.contextPath}/LogoutControlador" 
                           class="p-2 rounded-full text-slate-500 hover:text-red-600 hover:bg-red-100 transition-colors" 
                           title="Cerrar Sesión">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6a2.25 2.25 0 0 0-2.25 2.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15M15.75 9l-3.375 3.375M15.75 9h6.75m-6.75 0-3.375-3.375" /></svg>                            
                        </a>
                    </div>
                </header>
                <div id="subpage-content-admin" class="flex-1 p-8 overflow-y-auto">
                    <p>Cargando contenido...</p>
                </div>
            </div>
        </section>

    </main>
    
    <!-- Modal de Alerta -->
    <div id="alert-modal" class="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 hidden" style="animation-duration: 0.3s;">
        <div class="bg-white rounded-lg shadow-2xl p-6 max-w-sm w-full animate-fade-in" style="animation-duration: 0.3s;">
            <h3 id="alert-modal-title" class="text-lg font-bold text-slate-900 mb-4">Aviso</h3>
            <p id="alert-modal-message" class="text-slate-600 mb-6">Mensaje de alerta.</p>
            <button id="alert-modal-close" class="btn-fill-solid w-full" style="background-color: #3b82f6; border-color: #3b82f6;">Entendido</button>
        </div>
    </div>
    
    <!-- Modal para Subir/Editar Tesis -->
    <div id="modal-tesis" class="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 hidden">
        <div class="bg-white rounded-lg shadow-2xl p-6 max-w-md w-full max-h-[90vh] overflow-y-auto">
            <h3 id="modal-tesis-title" class="text-lg font-bold text-slate-900 mb-4">Subir Nueva Tesis</h3>
            <form id="form-tesis" class="space-y-4">
                <input type="hidden" id="tesis-id" name="idTesis">
                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-2">Título de la Tesis</label>
                    <input type="text" id="titulo-tesis" name="titulo" class="w-full px-4 py-3 rounded-lg border border-slate-300 bg-white text-slate-800 outline-none focus:ring-2 focus:ring-blue-500" required>
                </div>
                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-2">Autor (Alumno)</label>
                    <select id="autor-tesis" name="idAutor" class="w-full px-4 py-3 rounded-lg border border-slate-300 bg-white text-slate-800 outline-none focus:ring-2 focus:ring-blue-500" required>
                        <option value="">Seleccionar alumno</option>
                        <c:forEach var="estudiante" items="${listaEstudiantes}">
                            <option value="${estudiante.idUsuario}">${estudiante.nombre} ${estudiante.apellido}</option>
                        </c:forEach>
                        <c:if test="${empty listaEstudiantes}">
                            <option value="" disabled>No hay estudiantes disponibles</option>
                        </c:if>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-2">Archivo PDF</label>
                    <input type="file" id="archivo-tesis" name="archivo" accept=".pdf" class="w-full px-4 py-3 rounded-lg border border-slate-300 bg-white text-slate-800 outline-none focus:ring-2 focus:ring-blue-500">
                    <p class="text-xs text-slate-500 mt-1">Solo archivos PDF (máx. 10MB)</p>
                </div>
                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-2">Estado</label>
                    <select id="estado-tesis" name="estado" class="w-full px-4 py-3 rounded-lg border border-slate-300 bg-white text-slate-800 outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="Pendiente">Pendiente</option>
                        <option value="En Revisión">En Revisión</option>
                        <option value="Aprobado">Aprobado</option>
                        <option value="Rechazado">Rechazado</option>
                    </select>
                </div>
                <div class="flex space-x-3 pt-4">
                    <button type="submit" class="btn-fill-solid flex-1">Guardar</button>
                    <button type="button" id="modal-tesis-cancel" class="btn-fill flex-1">Cancelar</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Modal para Usuarios -->
    <div id="modal-usuario" class="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 hidden">
        <div class="bg-white rounded-lg shadow-2xl p-6 max-w-md w-full max-h-[90vh] overflow-y-auto">
            <h3 id="modal-usuario-title" class="text-lg font-bold text-slate-900 mb-4">Nuevo Usuario</h3>
            <form id="form-usuario" class="space-y-4">
                <input type="hidden" id="usuario-id" name="idUsuario">
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Nombre</label>
                        <input type="text" id="nombre-usuario" name="nombre" class="w-full px-4 py-3 rounded-lg border border-slate-300 bg-white text-slate-800 outline-none focus:ring-2 focus:ring-blue-500" required>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Apellido</label>
                        <input type="text" id="apellido-usuario" name="apellido" class="w-full px-4 py-3 rounded-lg border border-slate-300 bg-white text-slate-800 outline-none focus:ring-2 focus:ring-blue-500" required>
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-2">Email</label>
                    <input type="email" id="email-usuario" name="email" class="w-full px-4 py-3 rounded-lg border border-slate-300 bg-white text-slate-800 outline-none focus:ring-2 focus:ring-blue-500" required>
                </div>
                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-2">Nombre de Usuario</label>
                    <input type="text" id="username-usuario" name="nombreUsuario" class="w-full px-4 py-3 rounded-lg border border-slate-300 bg-white text-slate-800 outline-none focus:ring-2 focus:ring-blue-500" required>
                </div>
                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-2">Contraseña</label>
                    <input type="password" id="password-usuario" name="password" class="w-full px-4 py-3 rounded-lg border border-slate-300 bg-white text-slate-800 outline-none focus:ring-2 focus:ring-blue-500">
                    <p class="text-xs text-slate-500 mt-1">Dejar en blanco para mantener la actual</p>
                </div>
                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-2">Rol</label>
                    <select id="rol-usuario" name="rol" class="w-full px-4 py-3 rounded-lg border border-slate-300 bg-white text-slate-800 outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="estudiante">Estudiante</option>
                        <option value="docente">Docente</option>
                        <option value="admin">Administrador</option>
                    </select>
                </div>
                <div class="flex space-x-3 pt-4">
                    <button type="submit" class="btn-fill-solid flex-1">Guardar</button>
                    <button type="button" id="modal-usuario-cancel" class="btn-fill flex-1">Cancelar</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Modal de Confirmación -->
    <div id="modal-confirm" class="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 hidden">
        <div class="bg-white rounded-lg shadow-2xl p-6 max-w-sm w-full">
            <h3 id="modal-confirm-title" class="text-lg font-bold text-slate-900 mb-4">Confirmar Acción</h3>
            <p id="modal-confirm-message" class="text-slate-600 mb-6">¿Estás seguro de realizar esta acción?</p>
            <div class="flex space-x-3">
                <button id="modal-confirm-yes" class="btn-danger btn-fill-solid flex-1">Sí, eliminar</button>
                <button id="modal-confirm-no" class="btn-fill flex-1">Cancelar</button>
            </div>
        </div>
    </div>
    
    <!-- Modal para Generar Reportes -->
    <div id="modal-reporte" class="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 hidden">
        <div class="bg-white rounded-lg shadow-2xl p-6 max-w-md w-full">
            <h3 class="text-lg font-bold text-slate-900 mb-4">Generar Reporte</h3>
            <form id="form-reporte" class="space-y-4">
                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-2">Tipo de Reporte</label>
                    <select id="tipo-reporte" name="tipo" class="w-full px-4 py-3 rounded-lg border border-slate-300 bg-white text-slate-800 outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="general">Reporte General de Tesis</option>
                        <option value="docentes">Reporte de Rendimiento de Docentes</option>
                        <option value="alumnos">Listado de Alumnos sin Tesis</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-2">Formato</label>
                    <div class="flex space-x-4">
                        <label class="flex items-center">
                            <input type="radio" name="formato" value="pdf" checked class="mr-2">
                            <span>PDF</span>
                        </label>
                        <label class="flex items-center">
                            <input type="radio" name="formato" value="excel" class="mr-2">
                            <span>Excel</span>
                        </label>
                    </div>
                </div>
                <div class="flex space-x-3 pt-4">
                    <button type="submit" class="btn-success btn-fill-solid flex-1">Generar</button>
                    <button type="button" id="modal-reporte-cancel" class="btn-fill flex-1">Cancelar</button>
                </div>
            </form>
        </div>
    </div>

    <div id="content-templates" class="hidden">

        <%-- Plantilla: Gestión de Tesis --%>
        <template id="template-admin-gestion-tesis">
            <div class="bg-white p-8 rounded-lg shadow-md animate-fade-in">
                <!-- Depuración temporal -->
                <c:if test="${empty listaEstudiantes}">
                    <div class="mb-4 p-4 bg-yellow-100 text-yellow-800 rounded">
                        <h4 class="font-bold">Advertencia:</h4>
                        <p>No se encontraron estudiantes en la lista. Verifica en el controlador que se esté pasando la variable "listaEstudiantes".</p>
                    </div>
                </c:if>
                
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-2xl font-semibold text-slate-800">Gestión de Tesis</h3>
                    <button class="btn-fill-solid btn-subir-tesis">+ Subir Tesis</button>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-slate-200">
                        <thead class="bg-slate-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Título</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Autor (Alumno)</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Revisor (Docente)</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Estado</th>
                                <th class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Acciones</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-slate-200" id="tabla-tesis">
                            <c:choose>
                                <c:when test="${not empty listaTesisDetallada}">
                                    <c:forEach var="tesis" items="${listaTesisDetallada}">
                                        <tr data-tesis-id="${tesis.idTesis}">
                                            <td class="px-6 py-4 text-slate-700">${tesis.titulo}</td>
                                            <td class="px-6 py-4 text-slate-700">
                                                <!-- Mostrar autor directamente si ya viene en la tesis -->
                                                <c:choose>
                                                    <c:when test="${not empty tesis.nombreAutor}">
                                                        ${tesis.nombreAutor}
                                                    </c:when>
                                                    <c:otherwise>
                                                        <!-- Buscar el autor en la lista de estudiantes -->
                                                        <c:set var="nombreAutor" value="No encontrado" />
                                                        <c:forEach var="estudiante" items="${listaEstudiantes}">
                                                            <c:if test="${estudiante.idUsuario eq tesis.idAutor}">
                                                                <c:set var="nombreAutor" value="${estudiante.nombre} ${estudiante.apellido}" />
                                                            </c:if>
                                                        </c:forEach>
                                                        ${nombreAutor}
                                                    </c:otherwise>
                                                </c:choose>
                                            </td>
                                            <td class="px-6 py-4 text-slate-700">
                                                <c:choose>
                                                    <c:when test="${not empty tesis.nombreRevisor}">
                                                        ${tesis.nombreRevisor}
                                                    </c:when>
                                                    <c:otherwise>
                                                        <span class="text-xs text-yellow-600 font-bold">Sin Asignar</span>
                                                    </c:otherwise>
                                                </c:choose>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <c:choose>
                                                    <c:when test="${tesis.estado == 'Aprobado'}">
                                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                                            ${tesis.estado}
                                                        </span>
                                                    </c:when>
                                                    <c:when test="${tesis.estado == 'En Revisión'}">
                                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                                                            ${tesis.estado}
                                                        </span>
                                                    </c:when>
                                                    <c:when test="${tesis.estado == 'Pendiente'}">
                                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                                            ${tesis.estado}
                                                        </span>
                                                    </c:when>
                                                    <c:when test="${tesis.estado == 'Rechazado'}">
                                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                                                            ${tesis.estado}
                                                        </span>
                                                    </c:when>
                                                    <c:otherwise>
                                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                                                            ${tesis.estado}
                                                        </span>
                                                    </c:otherwise>
                                                </c:choose>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-2">
                                                <button class="text-blue-600 hover:text-blue-900 btn-editar-tesis" data-id="${tesis.idTesis}">Editar</button>
                                                <button class="text-red-600 hover:text-red-900 btn-eliminar-tesis" data-id="${tesis.idTesis}" data-titulo="${tesis.titulo}">Eliminar</button>
                                            </td>
                                        </tr>
                                    </c:forEach>
                                </c:when>
                                <c:otherwise>
                                    <tr>
                                        <td colspan="5" class="px-6 py-4 text-center text-slate-500">No hay tesis registradas.</td>
                                    </tr>
                                </c:otherwise>
                            </c:choose>
                        </tbody>
                    </table>
                </div>
            </div>
        </template>
        
        <%-- Plantilla: Gestión de Usuarios --%>
        <template id="template-admin-gestion-usuarios">
             <div class="bg-white p-8 rounded-lg shadow-md animate-fade-in">
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-2xl font-semibold text-slate-800">Gestión de Usuarios</h3>
                    <button class="btn-fill-solid btn-nuevo-usuario">+ Nuevo Usuario</button>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-slate-200">
                        <thead class="bg-slate-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Nombre</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Email / Usuario</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Rol</th>
                                <th class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Acciones</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-slate-200" id="tabla-usuarios">
                            <c:forEach var="usr" items="${listaUsuarios}">
                                <tr data-usuario-id="${usr.idUsuario}">
                                    <td class="px-6 py-4 text-slate-700">${usr.nombre} ${usr.apellido}</td>
                                    <td class="px-6 py-4 text-slate-700">${usr.email}<br><span class="text-xs text-slate-400">${usr.nombreUsuario}</span></td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <c:choose>
                                            <c:when test="${usr.rol == 'estudiante'}">
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                                                    ${usr.rol}
                                                </span>
                                            </c:when>
                                            <c:when test="${usr.rol == 'docente'}">
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                                    ${usr.rol}
                                                </span>
                                            </c:when>
                                            <c:when test="${usr.rol == 'admin'}">
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-purple-100 text-purple-800">
                                                    ${usr.rol}
                                                </span>
                                            </c:when>
                                            <c:otherwise>
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                                                    ${usr.rol}
                                                </span>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-2">
                                        <button class="text-blue-600 hover:text-blue-900 btn-editar-usuario" data-id="${usr.idUsuario}">Editar</button>
                                        <button class="text-red-600 hover:text-red-900 btn-eliminar-usuario" data-id="${usr.idUsuario}" data-nombre="${usr.nombre} ${usr.apellido}">Eliminar</button>
                                    </td>
                                </tr>
                            </c:forEach>
                            <c:if test="${empty listaUsuarios}">
                                <tr><td colspan="4" class="px-6 py-4 text-center text-slate-500">No hay usuarios registrados.</td></tr>
                            </c:if>
                        </tbody>
                    </table>
                </div>
            </div>
        </template>
        
        <%-- Plantilla: Asignar Revisiones --%>
        <template id="template-admin-asignar">
            <div class="bg-white p-8 rounded-lg shadow-md animate-fade-in">
                <h3 class="text-2xl font-semibold text-slate-800 mb-6">Asignar Revisión de Tesis</h3>
                    <form class="space-y-6 max-w-lg" action="${pageContext.request.contextPath}/dashboardAdmin" method="POST" id="form-asignar-revision">
                        <input type="hidden" name="accion" value="asignarRevision">
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Seleccionar Tesis (por Alumno)</label>
                        <select name="idTesis" class="w-full px-4 py-3 rounded-lg border border-slate-300 bg-white text-slate-800 outline-none focus:ring-2 focus:ring-blue-500">
                            <c:forEach var="tesis" items="${tesisSinAsignar}">
                                <option value="${tesis.idTesis}">${tesis.nombreAutor} - ${tesis.titulo}</option>
                            </c:forEach>
                            <c:if test="${empty tesisSinAsignar}">
                                <option disabled selected>No hay tesis pendientes de asignar</option>
                            </c:if>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Asignar a Docente (Revisor)</label>
                        <select name="idDocente" class="w-full px-4 py-3 rounded-lg border border-slate-300 bg-white text-slate-800 outline-none focus:ring-2 focus:ring-blue-500">
                             <c:forEach var="docente" items="${listaDocentes}">
                                <option value="${docente.idUsuario}">${docente.nombre} ${docente.apellido}</option>
                            </c:forEach>
                             <c:if test="${empty listaDocentes}">
                                <option disabled selected>No hay docentes activos</option>
                            </c:if>
                        </select>
                    </div>
                    <button type="submit" class="btn-fill-solid">Asignar</button>
                </form>
            </div>
        </template>
        
        <%-- Plantilla: Estadísticas --%>
        <template id="template-admin-estadisticas">
            <div class="bg-white p-8 rounded-lg shadow-md animate-fade-in">
                <h3 class="text-2xl font-semibold text-slate-800 mb-6">Estadísticas del Sistema</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="bg-slate-50 p-6 rounded-lg">
                        <h4 class="text-lg font-bold mb-4">Tesis por Estado</h4>
                        <div class="space-y-3">
                            <div class="flex justify-between text-sm"><span>Aprobadas</span><span>${conteoAprobadas}</span></div>
                            <div class="w-full bg-slate-200 rounded-full h-2.5"><div class="bg-green-600 h-2.5 rounded-full" style="width: ${conteoAprobadas/(conteoAprobadas+conteoEnRevision+conteoPendientes)*100}%"></div></div>
                            
                            <div class="flex justify-between text-sm"><span>En Revisión</span><span>${conteoEnRevision}</span></div>
                            <div class="w-full bg-slate-200 rounded-full h-2.5"><div class="bg-blue-600 h-2.5 rounded-full" style="width: ${conteoEnRevision/(conteoAprobadas+conteoEnRevision+conteoPendientes)*100}%"></div></div>
                            
                            <div class="flex justify-between text-sm"><span>Pendientes</span><span>${conteoPendientes}</span></div>
                            <div class="w-full bg-slate-200 rounded-full h-2.5"><div class="bg-yellow-500 h-2.5 rounded-full" style="width: ${conteoPendientes/(conteoAprobadas+conteoEnRevision+conteoPendientes)*100}%"></div></div>
                        </div>
                    </div>
                    <div class="bg-slate-50 p-6 rounded-lg">
                        <h4 class="text-lg font-bold mb-4">Usuarios Activos</h4>
                        <div class="text-4xl font-bold text-slate-800 mb-2">${totalUsuariosActivos}</div>
                        <p class="text-sm text-slate-500">Usuarios totales</p>
                        <div class="mt-4 flex space-x-4">
                            <span class="text-sm font-medium text-blue-700">${conteoEstudiantes} Estudiantes</span> | 
                            <span class="text-sm font-medium text-green-700">${conteoDocentes} Docentes</span> | 
                            <span class="text-sm font-medium text-purple-700">${conteoAdmins} Admins</span>
                        </div>
                    </div>
                </div>
            </div>
        </template>
        
        <%-- Plantilla: Reportes --%>
        <template id="template-admin-reportes">
            <div class="bg-white p-8 rounded-lg shadow-md animate-fade-in">
                <h3 class="text-2xl font-semibold text-slate-800 mb-6">Generar Reportes</h3>
                <p class="text-slate-600 mb-4">Selecciona el tipo de reporte que deseas generar (PDF/Excel).</p>
                <div class="space-y-4">
                    <button class="btn-fill w-full text-left btn-generar-reporte" data-tipo="general">📄 Reporte General de Tesis</button>
                    <button class="btn-fill w-full text-left btn-generar-reporte" data-tipo="docentes">📄 Reporte de Rendimiento de Docentes</button>
                    <button class="btn-fill w-full text-left btn-generar-reporte" data-tipo="alumnos">📄 Listado de Alumnos sin Tesis</button>
                </div>
            </div>
        </template>
        
        <%-- Plantilla: Configuración --%>
        <template id="template-admin-configuracion">
            <div class="bg-white p-8 rounded-lg shadow-md animate-fade-in">
                <h3 class="text-2xl font-semibold text-slate-800 mb-6">Configuración del Sistema</h3>
                <form class="space-y-6 max-w-lg" action="${pageContext.request.contextPath}/dashboardAdmin" method="POST" id="form-configuracion">
                    <input type="hidden" name="accion" value="actualizarConfig">
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Nombre de la Institución</label>
                        <input type="text" name="nombreInstitucion" class="w-full px-4 py-3 rounded-lg border border-slate-300 bg-white text-slate-800 outline-none focus:ring-2 focus:ring-blue-500" value="${config.nombreInstitucion}">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Logo de la Institución</label>
                        <input type="file" name="logo" class="w-full px-4 py-3 rounded-lg border border-slate-300 bg-white text-slate-800 outline-none focus:ring-2 focus:ring-blue-500"/>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Periodo Académico Actual</label>
                        <input type="text" name="periodoActual" class="w-full px-4 py-3 rounded-lg border border-slate-300 bg-white text-slate-800 outline-none focus:ring-2 focus:ring-blue-500" value="${config.periodoAcademico}">
                    </div>
                    <button type="submit" class="btn-fill-solid">Guardar Cambios</button>
                </form>
            </div>
        </template>

    </div> 
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Variables globales
            let currentAction = null;
            let itemToDelete = null;
            let itemType = null;
            
            // Navegación entre secciones
            document.querySelectorAll('.dashboard-card, .sidebar-link').forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    const targetPage = this.getAttribute('data-target-page');
                    const title = this.getAttribute('data-title');
                    const templateId = this.getAttribute('data-template-id');
                    
                    // Ocultar todas las secciones
                    document.querySelectorAll('main > section').forEach(section => {
                        section.classList.add('hidden');
                    });
                    
                    // Mostrar la sección objetivo
                    document.getElementById(targetPage).classList.remove('hidden');
                    
                    // Actualizar título
                    document.getElementById('subpage-title-admin').textContent = title;
                    
                    // Cargar contenido de la plantilla
                    const template = document.getElementById(templateId);
                    if (template) {
                        const contentContainer = document.getElementById('subpage-content-admin');
                        contentContainer.innerHTML = '';
                        const clone = document.importNode(template.content, true);
                        contentContainer.appendChild(clone);
                        
                        // Inicializar funcionalidades después de cargar la plantilla
                        setTimeout(initTemplateFunctionalities, 100);
                    }
                    
                    // Actualizar enlaces activos en sidebar
                    document.querySelectorAll('.sidebar-link').forEach(link => {
                        link.classList.remove('active');
                    });
                    this.classList.add('active');
                });
            });
            
            // Botón de volver
            document.querySelectorAll('.back-btn').forEach(button => {
                button.addEventListener('click', function() {
                    const targetDashboard = this.getAttribute('data-target-dashboard');
                    
                    // Ocultar todas las secciones
                    document.querySelectorAll('main > section').forEach(section => {
                        section.classList.add('hidden');
                    });
                    
                    // Mostrar el dashboard principal
                    document.getElementById(targetDashboard).classList.remove('hidden');
                    
                    // Limpiar enlaces activos
                    document.querySelectorAll('.sidebar-link').forEach(link => {
                        link.classList.remove('active');
                    });
                });
            });
            
            // Modal de alerta
            const alertModal = document.getElementById('alert-modal');
            const alertModalClose = document.getElementById('alert-modal-close');
            
            if (alertModalClose) {
                alertModalClose.addEventListener('click', function() {
                    alertModal.classList.add('hidden');
                });
            }
            
            // Cerrar modal al hacer clic fuera
            alertModal.addEventListener('click', function(e) {
                if (e.target === alertModal) {
                    alertModal.classList.add('hidden');
                }
            });
            
            // Función para mostrar alertas
            window.showAlert = function(title, message, type = 'info') {
                document.getElementById('alert-modal-title').textContent = title;
                document.getElementById('alert-modal-message').textContent = message;
                alertModal.classList.remove('hidden');
            };
            
            // Modal de Tesis
            const modalTesis = document.getElementById('modal-tesis');
            const modalTesisCancel = document.getElementById('modal-tesis-cancel');
            
            modalTesisCancel.addEventListener('click', function() {
                modalTesis.classList.add('hidden');
                document.getElementById('form-tesis').reset();
            });
            
            // Modal de Usuario
            const modalUsuario = document.getElementById('modal-usuario');
            const modalUsuarioCancel = document.getElementById('modal-usuario-cancel');
            
            modalUsuarioCancel.addEventListener('click', function() {
                modalUsuario.classList.add('hidden');
                document.getElementById('form-usuario').reset();
            });
            
            // Modal de Confirmación
            const modalConfirm = document.getElementById('modal-confirm');
            const modalConfirmYes = document.getElementById('modal-confirm-yes');
            const modalConfirmNo = document.getElementById('modal-confirm-no');
            
            modalConfirmNo.addEventListener('click', function() {
                modalConfirm.classList.add('hidden');
            });
            
            modalConfirmYes.addEventListener('click', function() {
                if (itemType === 'tesis') {
                    eliminarTesis(itemToDelete);
                } else if (itemType === 'usuario') {
                    eliminarUsuario(itemToDelete);
                }
                modalConfirm.classList.add('hidden');
            });
            
            // Modal de Reportes
            const modalReporte = document.getElementById('modal-reporte');
            const modalReporteCancel = document.getElementById('modal-reporte-cancel');
            
            modalReporteCancel.addEventListener('click', function() {
                modalReporte.classList.add('hidden');
            });
            
            // Cerrar modales al hacer clic fuera
            [modalTesis, modalUsuario, modalConfirm, modalReporte].forEach(modal => {
                modal.addEventListener('click', function(e) {
                    if (e.target === modal) {
                        modal.classList.add('hidden');
                    }
                });
            });
            
            // Inicializar funcionalidades de plantillas
            function initTemplateFunctionalities() {
                // Botón Subir Tesis
                document.querySelectorAll('.btn-subir-tesis').forEach(btn => {
                    btn.addEventListener('click', function() {
                        document.getElementById('modal-tesis-title').textContent = 'Subir Nueva Tesis';
                        document.getElementById('form-tesis').reset();
                        document.getElementById('tesis-id').value = '';
                        modalTesis.classList.remove('hidden');
                        
                        // Cargar estudiantes dinámicamente si es necesario
                        cargarEstudiantesEnSelect();
                    });
                });
                
                // Botones Editar Tesis
                document.querySelectorAll('.btn-editar-tesis').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const tesisId = this.getAttribute('data-id');
                        const row = this.closest('tr');
                        
                        // Obtener datos de la fila
                        const titulo = row.querySelector('td:nth-child(1)').textContent.trim();
                        const autorTexto = row.querySelector('td:nth-child(2)').textContent.trim();
                        
                        document.getElementById('modal-tesis-title').textContent = 'Editar Tesis';
                        document.getElementById('tesis-id').value = tesisId;
                        document.getElementById('titulo-tesis').value = titulo;
                        
                        // Intentar encontrar el autor en el select
                        const selectAutor = document.getElementById('autor-tesis');
                        let encontrado = false;
                        for (let i = 0; i < selectAutor.options.length; i++) {
                            if (selectAutor.options[i].text === autorTexto) {
                                selectAutor.value = selectAutor.options[i].value;
                                encontrado = true;
                                break;
                            }
                        }
                        
                        if (!encontrado) {
                            // Si no se encuentra, dejar el primer valor
                            selectAutor.value = selectAutor.options[0].value;
                        }
                        
                        // Obtener el estado de la fila
                        const estadoSpan = row.querySelector('td:nth-child(4) span');
                        if (estadoSpan) {
                            const estado = estadoSpan.textContent.trim();
                            document.getElementById('estado-tesis').value = estado;
                        }
                        
                        modalTesis.classList.remove('hidden');
                    });
                });
                
                // Botones Eliminar Tesis
                document.querySelectorAll('.btn-eliminar-tesis').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const tesisId = this.getAttribute('data-id');
                        const titulo = this.getAttribute('data-titulo');
                        itemToDelete = tesisId;
                        itemType = 'tesis';
                        document.getElementById('modal-confirm-title').textContent = 'Eliminar Tesis';
                        document.getElementById('modal-confirm-message').textContent = `¿Estás seguro de eliminar la tesis "${titulo}"?`;
                        modalConfirm.classList.remove('hidden');
                    });
                });
                
                // Botón Nuevo Usuario
                document.querySelectorAll('.btn-nuevo-usuario').forEach(btn => {
                    btn.addEventListener('click', function() {
                        document.getElementById('modal-usuario-title').textContent = 'Nuevo Usuario';
                        document.getElementById('form-usuario').reset();
                        document.getElementById('usuario-id').value = '';
                        document.getElementById('password-usuario').required = true;
                        modalUsuario.classList.remove('hidden');
                    });
                });
                
                // Botones Editar Usuario
                document.querySelectorAll('.btn-editar-usuario').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const usuarioId = this.getAttribute('data-id');
                        const row = this.closest('tr');
                        
                        // Obtener datos de la fila
                        const nombreCompleto = row.querySelector('td:nth-child(1)').textContent.trim();
                        const email = row.querySelector('td:nth-child(2)').textContent.split('\n')[0].trim();
                        const rolSpan = row.querySelector('td:nth-child(3) span');
                        const rol = rolSpan ? rolSpan.textContent.trim() : 'estudiante';
                        
                        document.getElementById('modal-usuario-title').textContent = 'Editar Usuario';
                        document.getElementById('usuario-id').value = usuarioId;
                        
                        // Separar nombre y apellido
                        const partes = nombreCompleto.split(' ');
                        document.getElementById('nombre-usuario').value = partes[0] || '';
                        document.getElementById('apellido-usuario').value = partes.slice(1).join(' ') || '';
                        
                        document.getElementById('email-usuario').value = email;
                        document.getElementById('username-usuario').value = email.split('@')[0] || '';
                        document.getElementById('password-usuario').required = false;
                        document.getElementById('rol-usuario').value = rol;
                        
                        modalUsuario.classList.remove('hidden');
                    });
                });
                
                // Botones Eliminar Usuario
                document.querySelectorAll('.btn-eliminar-usuario').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const usuarioId = this.getAttribute('data-id');
                        const nombre = this.getAttribute('data-nombre');
                        itemToDelete = usuarioId;
                        itemType = 'usuario';
                        document.getElementById('modal-confirm-title').textContent = 'Eliminar Usuario';
                        document.getElementById('modal-confirm-message').textContent = `¿Estás seguro de eliminar al usuario "${nombre}"?`;
                        modalConfirm.classList.remove('hidden');
                    });
                });
                
                // Botones Generar Reporte
                document.querySelectorAll('.btn-generar-reporte').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const tipo = this.getAttribute('data-tipo');
                        document.getElementById('tipo-reporte').value = tipo;
                        modalReporte.classList.remove('hidden');
                    });
                });
                
                // Formulario de Tesis
                document.getElementById('form-tesis')?.addEventListener('submit', function(e) {
                    e.preventDefault();
                    const formData = new FormData(this);
                    const tesisId = document.getElementById('tesis-id').value;
                    const action = tesisId ? 'actualizarTesis' : 'subirTesis';
                    
                    formData.append('accion', action);
                    if (tesisId) {
                        formData.append('idTesis', tesisId);
                    }
                    
                    enviarFormulario('${pageContext.request.contextPath}/dashboardAdmin', formData, 'Tesis guardada exitosamente');
                });
                
                // Formulario de Usuario
                document.getElementById('form-usuario')?.addEventListener('submit', function(e) {
                    e.preventDefault();
                    const formData = new FormData(this);
                    const usuarioId = document.getElementById('usuario-id').value;
                    const action = usuarioId ? 'actualizarUsuario' : 'crearUsuario';
                    
                    formData.append('accion', action);
                    if (usuarioId) {
                        formData.append('idUsuario', usuarioId);
                    }
                    
                    enviarFormulario('${pageContext.request.contextPath}/dashboardAdmin', formData, 'Usuario guardado exitosamente');
                });
                
                // Formulario de Reporte
                document.getElementById('form-reporte')?.addEventListener('submit', function(e) {
                    e.preventDefault();
                    const formData = new FormData(this);
                    formData.append('accion', 'generarReporte');
                    
                    enviarFormulario('${pageContext.request.contextPath}/dashboardAdmin', formData, 'Reporte generado exitosamente');
                    modalReporte.classList.add('hidden');
                });
                
                // Formulario de Asignar Revisión
                document.getElementById('form-asignar-revision')?.addEventListener('submit', function(e) {
                    e.preventDefault();
                    const formData = new FormData(this);
                    
                    enviarFormulario('${pageContext.request.contextPath}/dashboardAdmin', formData, 'Revisión asignada exitosamente');
                });
                
                // Formulario de Configuración
                document.getElementById('form-configuracion')?.addEventListener('submit', function(e) {
                    e.preventDefault();
                    const formData = new FormData(this);
                    
                    enviarFormulario('${pageContext.request.contextPath}/dashboardAdmin', formData, 'Configuración guardada exitosamente');
                });
            }
            
            // Función para cargar estudiantes dinámicamente
            function cargarEstudiantesEnSelect() {
                const select = document.getElementById('autor-tesis');
                if (select && select.options.length <= 2) { // Solo si tiene pocas opciones
                    fetch('${pageContext.request.contextPath}/dashboardAdmin?accion=obtenerEstudiantes')
                        .then(response => response.json())
                        .then(data => {
                            if (data && data.length > 0) {
                                select.innerHTML = '<option value="">Seleccionar alumno</option>';
                                data.forEach(estudiante => {
                                    const option = document.createElement('option');
                                    option.value = estudiante.idUsuario;
                                    option.textContent = `${estudiante.nombre} ${estudiante.apellido}`;
                                    select.appendChild(option);
                                });
                            }
                        })
                        .catch(error => console.error('Error cargando estudiantes:', error));
                }
            }
            
            // Función para enviar formularios
            function enviarFormulario(url, formData, successMessage) {
                fetch(url, {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showAlert('Éxito', successMessage, 'success');
                        setTimeout(() => {
                            location.reload();
                        }, 1500);
                    } else {
                        showAlert('Error', data.message || 'Ha ocurrido un error', 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showAlert('Error', 'Error de conexión con el servidor', 'error');
                });
            }
            
            // Función para eliminar tesis
            function eliminarTesis(tesisId) {
                const formData = new FormData();
                formData.append('accion', 'eliminarTesis');
                formData.append('idTesis', tesisId);
                
                enviarFormulario('${pageContext.request.contextPath}/dashboardAdmin', formData, 'Tesis eliminada exitosamente');
            }
            
            // Función para eliminar usuario
            function eliminarUsuario(usuarioId) {
                const formData = new FormData();
                formData.append('accion', 'eliminarUsuario');
                formData.append('idUsuario', usuarioId);
                
                enviarFormulario('${pageContext.request.contextPath}/dashboardAdmin', formData, 'Usuario eliminado exitosamente');
            }
            
            // Mostrar alerta si hay un mensaje en la sesión
            <% if (request.getAttribute("mensaje") != null) { %>
                showAlert('Información', '<%= request.getAttribute("mensaje") %>');
            <% } %>
            
            // Inicializar funcionalidades al cargar
            initTemplateFunctionalities();
        });
    </script>
    
</body>
</html>