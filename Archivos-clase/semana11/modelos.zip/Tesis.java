package com.mitesis.modelos;

import java.io.Serializable;
import java.util.Date; // Usamos java.util.Date para la fecha

/**
 * Modelo (JavaBean) que representa la entidad Tesis.
 * Esta es la entidad central del negocio.
 */
public class Tesis implements Serializable {
    
    private int idTesis;
    private String titulo;
    private String descripcion;
    private Date fechaSubida; // Se mapea a un 'DATETIME' o 'TIMESTAMP' en MySQL
    private String estado; // "Pendiente", "En Revisión", "Aprobado", "Rechazado"
    private String urlArchivo; // Ruta donde se guarda el PDF en el servidor
    private Date fechaProximaRevision; // Para el calendario y dashboard
    
    // --- Relaciones (Llaves Foráneas) ---
    // Guardamos los IDs del autor y revisor
    private int idEstudianteAutor;
    private int idDocenteRevisor;
    
    private String nombreAutor;
    private String nombreRevisor;
    
    // Constructor vacío
    public Tesis() {
    }

    // Constructor completo
    public Tesis(int idTesis, String titulo, String descripcion, Date fechaSubida, String estado, String urlArchivo, int idEstudianteAutor, int idDocenteRevisor) {
        this.idTesis = idTesis;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.fechaSubida = fechaSubida;
        this.estado = estado;
        this.urlArchivo = urlArchivo;
        this.idEstudianteAutor = idEstudianteAutor;
        this.idDocenteRevisor = idDocenteRevisor;
        this.fechaProximaRevision = null; // Se puede añadir al constructor si se desea
    }

    // --- Getters y Setters ---
    
    public int getIdTesis() {
        return idTesis;
    }

    public void setIdTesis(int idTesis) {
        this.idTesis = idTesis;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Date getFechaSubida() {
        return fechaSubida;
    }

    public void setFechaSubida(Date fechaSubida) {
        this.fechaSubida = fechaSubida;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getUrlArchivo() {
        return urlArchivo;
    }

    public void setUrlArchivo(String urlArchivo) {
        this.urlArchivo = urlArchivo;
    }

    public Date getFechaProximaRevision() {
        return fechaProximaRevision;
    }

    public void setFechaProximaRevision(Date fechaProximaRevision) {
        this.fechaProximaRevision = fechaProximaRevision;
    }

    public int getIdEstudianteAutor() {
        return idEstudianteAutor;
    }

    public void setIdEstudianteAutor(int idEstudianteAutor) {
        this.idEstudianteAutor = idEstudianteAutor;
    }

    public int getIdDocenteRevisor() {
        return idDocenteRevisor;
    }

    public void setIdDocenteRevisor(int idDocenteRevisor) {
        this.idDocenteRevisor = idDocenteRevisor;
    }

    public String getNombreAutor() {
        return nombreAutor;
    }

    public void setNombreAutor(String nombreAutor) {
        this.nombreAutor = nombreAutor;
    }

    public String getNombreRevisor() {
        return nombreRevisor;
    }

    public void setNombreRevisor(String nombreRevisor) {
        this.nombreRevisor = nombreRevisor;
    }
    @Override
    public String toString() {
        return "Tesis{" + "idTesis=" + idTesis + ", titulo=" + titulo + ", estado=" + estado + '}';
    }
}