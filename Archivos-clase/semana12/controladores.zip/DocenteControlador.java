package com.mitesis.controladores;

// DAOs
import com.mitesis.dao.EventoCalendarioDAO;
import com.mitesis.dao.MensajeDAO;
import com.mitesis.dao.TesisDAO;
import com.mitesis.dao.UsuarioDAO; // <-- Importante

// Modelos
import com.mitesis.modelos.Docente;
import com.mitesis.modelos.EventoCalendario;
import com.mitesis.modelos.Mensaje;
import com.mitesis.modelos.Tesis;

// Java Utils
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

// Jakarta Servlet API
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet (Controlador) para el Dashboard del Docente.
 * Maneja doGet (cargar datos) y doPost (procesar acciones).
 */
@WebServlet(name = "DocenteControlador", urlPatterns = {"/dashboardDocente"})
public class DocenteControlador extends HttpServlet {

    // --- Instancias de los DAOs ---
    private TesisDAO tesisDAO = new TesisDAO();
    private MensajeDAO mensajeDAO = new MensajeDAO();
    private EventoCalendarioDAO calendarioDAO = new EventoCalendarioDAO();
    private UsuarioDAO usuarioDAO = new UsuarioDAO(); // <-- Añadido para actualizar perfil

    //
    // --- MÉTODO doGet: Carga los datos y muestra la página ---
    //
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        Docente docente = (Docente) session.getAttribute("usuario");

        // 2. (Modelo) Llamar a los DAOs
        List<Tesis> tesisAsignadas = tesisDAO.obtenerTesisPorDocente(docente.getIdUsuario());
        List<Tesis> tesisRevisadas = tesisDAO.obtenerTesisRevisadasPorDocente(docente.getIdUsuario());
        List<Mensaje> mensajes = mensajeDAO.obtenerMensajesRecibidos(docente.getIdUsuario());
        List<EventoCalendario> eventos = calendarioDAO.obtenerEventos();
        
        List<Tesis> tesisPendientes = tesisAsignadas.stream()
                .filter(t -> t.getEstado().equals("En Revisión") || t.getEstado().equals("Requiere Correcciones"))
                .collect(Collectors.toList());
        
        long mensajesNoLeidos = mensajes.stream().filter(m -> !m.isLeido()).count();

        // 3. (Vista) Empaquetar todos los datos
        request.setAttribute("tesisAsignadas", tesisAsignadas);
        request.setAttribute("tesisRevisadas", tesisRevisadas);
        request.setAttribute("mensajes", mensajes);
        request.setAttribute("eventos", eventos);
        request.setAttribute("tesisPendientesCount", tesisPendientes.size());
        request.setAttribute("mensajesNoLeidosCount", mensajesNoLeidos);

        // 4. Despachar (Forward) la petición al JSP
        RequestDispatcher dispatcher = request.getRequestDispatcher("docente.jsp");
        dispatcher.forward(request, response);
    }

    //
    // --- MÉTODO doPost: Procesa las acciones de los formularios ---
    //
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String accion = request.getParameter("accion");
        HttpSession session = request.getSession(false);
        Docente docente = (Docente) session.getAttribute("usuario");
        
        if (accion == null) accion = "";

        try {
            switch (accion) {
                
                case "calificarTesis":
                    handleCalificarTesis(request, docente);
                    break;
                    
                case "enviarMensaje":
                    handleEnviarMensaje(request, docente);
                    break;
                    
                case "actualizarPerfil":
                    handleActualizarPerfil(request, docente);
                    break;
                    
                default:
                    System.out.println("Acción POST desconocida: " + accion);
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            // session.setAttribute("error", "Error al procesar la solicitud: " + e.getMessage());
        }

        // --- Patrón PRG (Post-Redirect-Get) ---
        response.sendRedirect(request.getContextPath() + "/dashboardDocente");
    }

    /**
     * Lógica para "calificarTesis" (¡CORREGIDA!)
     */
    private void handleCalificarTesis(HttpServletRequest request, Docente docente) {
        try {
            int idTesis = Integer.parseInt(request.getParameter("idTesis"));
            String nuevoEstado = request.getParameter("nuevoEstado");
            String comentarios = request.getParameter("comentarios");
            int idDocente = docente.getIdUsuario();
            
            // --- ¡CORRECCIÓN! ---
            // Llamamos al método que SÍ existe (el que acabamos de añadir al TesisDAO)
            tesisDAO.actualizarEstadoPorDocente(idTesis, idDocente, nuevoEstado, comentarios);
            
            // session.setAttribute("exito", "Tesis calificada correctamente.");
            
        } catch (Exception e) {
            System.err.println("Error en handleCalificarTesis: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Lógica para "enviarMensaje" (¡CORREGIDA!)
     */
    private void handleEnviarMensaje(HttpServletRequest request, Docente docente) {
        try {
            // NOTA: El JSP del chat de docente necesita un <input type="hidden" name="destinatarioId">
            int idDestinatario = Integer.parseInt(request.getParameter("destinatarioId"));
            String cuerpoMensaje = request.getParameter("contenido");
            int idRemitente = docente.getIdUsuario();
            
            // --- ¡CORRECCIÓN! (Coincide con tu MensajeDAO) ---
            Mensaje nuevoMensaje = new Mensaje();
            nuevoMensaje.setAsunto("Mensaje de Docente"); // Asunto genérico
            nuevoMensaje.setCuerpo(cuerpoMensaje); // Usamos setCuerpo
            nuevoMensaje.setIdRemitente(idRemitente);
            nuevoMensaje.setIdDestinatario(idDestinatario);
            
            mensajeDAO.enviarMensaje(nuevoMensaje);
            
        } catch (Exception e) {
            System.err.println("Error en handleEnviarMensaje: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Lógica para "actualizarPerfil" (¡CORREGIDA!)
     */
    private void handleActualizarPerfil(HttpServletRequest request, Docente docente) {
         try {
            String email = request.getParameter("email");
            String nuevaClave = request.getParameter("nuevaClave");
            String especialidad = request.getParameter("especialidad");
            
            // 1. Actualizar datos en la BBDD (email y clave)
            // (Usamos el método que añadimos al UsuarioDAO)
            usuarioDAO.actualizarPerfil(docente.getIdUsuario(), email, nuevaClave);
            
            // 2. Actualizar la info específica de Docente (especialidad)
            // ¡Este método también falta en UsuarioDAO!
            // usuarioDAO.actualizarEspecialidadDocente(docente.getIdUsuario(), especialidad);
            System.out.println("Lógica de 'actualizarEspecialidadDocente' pendiente en UsuarioDAO.");


            // 3. Actualizar el objeto en la sesión
            docente.setEmail(email);
            docente.setEspecialidad(especialidad);
            request.getSession().setAttribute("usuario", docente);
            
        } catch (Exception e) {
            System.err.println("Error en handleActualizarPerfil: " + e.getMessage());
            e.printStackTrace();
        }
    }
}