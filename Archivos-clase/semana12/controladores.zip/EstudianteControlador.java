package com.mitesis.controladores;

// DAOs
import com.mitesis.dao.EventoCalendarioDAO;
import com.mitesis.dao.MensajeDAO;
import com.mitesis.dao.TesisDAO;
import com.mitesis.dao.UsuarioDAO;

// Modelos
import com.mitesis.modelos.Estudiante;
import com.mitesis.modelos.Tesis;
import com.mitesis.modelos.Mensaje;
import com.mitesis.modelos.EventoCalendario;

// Java Utils
import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;

// Jakarta Servlet API
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;

/**
 * Servlet (Controlador) para el Dashboard del Estudiante.
 * Maneja doGet (cargar datos) y doPost (procesar acciones).
 * Habilitado para subida de archivos (Multipart).
 */
@WebServlet(name = "EstudianteControlador", urlPatterns = {"/dashboardEstudiante"})
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 1, // 1 MB
    maxFileSize = 1024 * 1024 * 20,      // 20 MB
    maxRequestSize = 1024 * 1024 * 25   // 25 MB
)
public class EstudianteControlador extends HttpServlet {

    // --- Instancias de los DAOs ---
    private TesisDAO tesisDAO = new TesisDAO();
    private MensajeDAO mensajeDAO = new MensajeDAO();
    private EventoCalendarioDAO calendarioDAO = new EventoCalendarioDAO();
    private UsuarioDAO usuarioDAO = new UsuarioDAO();

    //
    // --- MÉTODO doGet (Sin cambios) ---
    //
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        Estudiante estudiante = (Estudiante) session.getAttribute("usuario");

        Tesis miTesis = tesisDAO.obtenerTesisPorEstudiante(estudiante.getIdUsuario());
        List<Mensaje> mensajes = mensajeDAO.obtenerMensajesRecibidos(estudiante.getIdUsuario());
        List<EventoCalendario> eventos = calendarioDAO.obtenerEventos();
        
        long mensajesNoLeidos = mensajes.stream()
                                    .filter(m -> !m.isLeido())
                                    .count();

        request.setAttribute("miTesis", miTesis);
        request.setAttribute("mensajes", mensajes);
        request.setAttribute("eventos", eventos);
        request.setAttribute("mensajesNoLeidosCount", mensajesNoLeidos);

        RequestDispatcher dispatcher = request.getRequestDispatcher("estudiante.jsp");
        dispatcher.forward(request, response);
    }

    //
    // --- MÉTODO doPost (Sin cambios, pero el 'handle' está corregido) ---
    //
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String accion = request.getParameter("accion");
        HttpSession session = request.getSession(false);
        Estudiante estudiante = (Estudiante) session.getAttribute("usuario");
        
        if (accion == null) accion = "";

        try {
            switch(accion) {
                case "subirArchivo":
                    handleSubirArchivo(request, estudiante);
                    break;
                case "enviarMensaje":
                    handleEnviarMensaje(request, estudiante); // <-- Esta función está corregida
                    break;
                case "actualizarPerfil":
                    handleActualizarPerfil(request, estudiante);
                    break;
                default:
                    System.out.println("Acción POST desconocida: " + accion);
            }
        } catch (Exception e) {
            e.printStackTrace();
            // session.setAttribute("error", "Error al procesar la solicitud: " + e.getMessage());
        }

        response.sendRedirect(request.getContextPath() + "/dashboardEstudiante");
    }

    /**
     * Lógica para "subirArchivo"
     */
    // En com.mitesis.controladores.EstudianteControlador

private void handleSubirArchivo(HttpServletRequest request, Estudiante estudiante) 
        throws IOException, ServletException {
    try {
        // 1. Obtener parámetros
        String tipoEntrega = request.getParameter("tipoEntrega");
        String comentarios = request.getParameter("comentarios");
        Part filePart = request.getPart("archivo");
        
        // 2. Validar que se haya enviado un archivo
        if (filePart == null || filePart.getSize() == 0) {
            request.getSession().setAttribute("error", "Debes seleccionar un archivo.");
            return;
        }

        // 3. Preparar nombre y ruta única (para evitar sobrescribir archivos con el mismo nombre)
        // Ejemplo: 20231010_12345_MiTesis.pdf
        String originalName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
        String uniqueName = System.currentTimeMillis() + "_" + estudiante.getIdUsuario() + "_" + originalName;
        
        // Ruta física en el servidor (carpeta 'uploads')
        String uploadPath = getServletContext().getRealPath("") + File.separator + "uploads";
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) uploadDir.mkdir();

        // 4. Guardar archivo en disco
        String savePath = uploadPath + File.separator + uniqueName;
        filePart.write(savePath);

        // 5. Guardar referencia en BBDD (Ruta relativa para poder usarla en HTML)
        String dbPath = "uploads/" + uniqueName; 
        
        // Llamamos al método del DAO que acabamos de crear
        boolean resultado = tesisDAO.registrarEntrega(estudiante.getIdUsuario(), tipoEntrega, comentarios, dbPath);

        if (resultado) {
            request.getSession().setAttribute("exito", "Archivo subido correctamente. Tu tesis está en estado Pendiente.");
        } else {
            request.getSession().setAttribute("error", "El archivo se subió, pero hubo un error al actualizar la base de datos.");
        }

    } catch (Exception e) {
        e.printStackTrace();
        request.getSession().setAttribute("error", "Error crítico al subir archivo: " + e.getMessage());
    }
}
    
    /**
     * Lógica para "enviarMensaje" (¡CORREGIDA!)
     */
    private void handleEnviarMensaje(HttpServletRequest request, Estudiante estudiante) {
        try {
            // 1. Obtener datos del formulario
            int idDestinatario = Integer.parseInt(request.getParameter("destinatarioId"));
            String cuerpoMensaje = request.getParameter("contenido"); // El <input> del JSP se llama 'contenido'
            int idRemitente = estudiante.getIdUsuario();
            
            // --- ¡AQUÍ LA CORRECCIÓN! ---
            Mensaje nuevoMensaje = new Mensaje();
            
            // 2. El DAO requiere un 'asunto' (parámetro 1), pero el form de chat no lo tiene.
            //    Le asignamos un asunto genérico.
            nuevoMensaje.setAsunto("Mensaje de Estudiante"); 
            
            // 3. El DAO requiere 'cuerpo' (parámetro 2), no 'contenido'.
            //    Asumimos que tu Modelo Mensaje.java tiene el método 'setCuerpo()'.
            nuevoMensaje.setCuerpo(cuerpoMensaje); 
            
            // 4. Asignar IDs
            nuevoMensaje.setIdRemitente(idRemitente);
            nuevoMensaje.setIdDestinatario(idDestinatario);
            
            // 5. Llamar al DAO
            mensajeDAO.enviarMensaje(nuevoMensaje);
            
        } catch (Exception e) {
            System.err.println("Error en handleEnviarMensaje: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Lógica para "actualizarPerfil" (Corregida anteriormente)
     */
    private void handleActualizarPerfil(HttpServletRequest request, Estudiante estudiante) {
         try {
            String email = request.getParameter("email");
            String nuevaClave = request.getParameter("nuevaClave");
            
            // Llamamos al método que SÍ existe en tu UsuarioDAO
            usuarioDAO.actualizarPerfil(estudiante.getIdUsuario(), email, nuevaClave);

            // Actualizar la sesión
            estudiante.setEmail(email);
            request.getSession().setAttribute("usuario", estudiante);
            
        } catch (Exception e) {
            System.err.println("Error en handleActualizarPerfil: " + e.getMessage());
            e.printStackTrace();
        }
    }
}