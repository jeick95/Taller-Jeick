package com.mitesis.controladores;

// DAOs
import com.mitesis.dao.ConfiguracionSistemaDAO;
import com.mitesis.dao.TesisDAO;
import com.mitesis.dao.UsuarioDAO;

// Modelos
import com.mitesis.modelos.ConfiguracionSistema;
import com.mitesis.modelos.Docente;
import com.mitesis.modelos.Tesis;
import com.mitesis.modelos.Usuario;

// Java Utils
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

// Jakarta Servlet API
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet (Controlador) para el Dashboard del Administrador.
 * Maneja doGet (cargar datos) y doPost (procesar acciones).
 */
@WebServlet(name = "AdminControlador", urlPatterns = {"/dashboardAdmin"})
public class AdminControlador extends HttpServlet {

    // --- Instancias de los DAOs ---
    private UsuarioDAO usuarioDAO = new UsuarioDAO();
    private TesisDAO tesisDAO = new TesisDAO();
    private ConfiguracionSistemaDAO configDAO = new ConfiguracionSistemaDAO();

    //
    // --- MÉTODO doGet: Carga los datos y muestra la página ---
    //
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // 1. (Modelo) Llamar a todos los DAOs para obtener los datos
        List<Usuario> listaUsuarios = usuarioDAO.listarTodosLosUsuarios();
        List<Tesis> listaTesisDetallada = tesisDAO.obtenerTodasLasTesisDetallado();
        List<Tesis> tesisSinAsignar = tesisDAO.obtenerTesisSinAsignar();
        List<Docente> listaDocentes = usuarioDAO.listarDocentesActivos();
        ConfiguracionSistema config = configDAO.obtenerConfiguracion();
        int totalUsuariosActivos = usuarioDAO.contarUsuariosActivos();
        int totalTesis = listaTesisDetallada.size();
        
        // Estadísticas de Tesis
        Map<String, Long> conteoPorEstado = listaTesisDetallada.stream()
                .collect(Collectors.groupingBy(Tesis::getEstado, Collectors.counting()));

        // Estadísticas de Usuarios
        Map<String, Long> conteoPorRol = listaUsuarios.stream()
                .collect(Collectors.groupingBy(Usuario::getRol, Collectors.counting()));
        
        // 2. (Vista) Empaquetar todos los datos y enviarlos al JSP
        
        // Listas
        request.setAttribute("listaUsuarios", listaUsuarios);
        request.setAttribute("listaTesisDetallada", listaTesisDetallada);
        request.setAttribute("tesisSinAsignar", tesisSinAsignar);
        request.setAttribute("listaDocentes", listaDocentes);
        
        // Objetos
        request.setAttribute("config", config);
        
        // Conteos para el Panel Principal
        request.setAttribute("totalTesis", totalTesis);
        request.setAttribute("totalUsuariosActivos", totalUsuariosActivos);
        
        // Conteos para la página de Estadísticas
        request.setAttribute("conteoAprobadas", conteoPorEstado.getOrDefault("Aprobado", 0L));
        request.setAttribute("conteoEnRevision", conteoPorEstado.getOrDefault("En Revisión", 0L));
        request.setAttribute("conteoPendientes", conteoPorEstado.getOrDefault("Pendiente", 0L));
        request.setAttribute("conteoRechazadas", conteoPorEstado.getOrDefault("Rechazado", 0L));
        request.setAttribute("conteoCorrecciones", conteoPorEstado.getOrDefault("Requiere Correcciones", 0L));
        
        request.setAttribute("conteoEstudiantes", conteoPorRol.getOrDefault("estudiante", 0L));
        request.setAttribute("conteoDocentes", conteoPorRol.getOrDefault("docente", 0L));
        request.setAttribute("conteoAdmins", conteoPorRol.getOrDefault("admin", 0L));
        
        // 3. Despachar (Forward) la petición al JSP
        RequestDispatcher dispatcher = request.getRequestDispatcher("admin.jsp");
        dispatcher.forward(request, response);
    }

    //
    // --- MÉTODO doPost: Procesa las acciones de los formularios ---
    //
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Obtenemos la acción del formulario (ej. "asignarRevision")
        String accion = request.getParameter("accion");
        
        // Obtenemos al usuario (Admin) de la sesión
        HttpSession session = request.getSession(false);
        Usuario admin = (Usuario) session.getAttribute("usuario");
        
        if (accion == null) {
            accion = ""; // Evitar NullPointerException
        }

        try {
            // Decidimos qué hacer
            switch (accion) {
                
                case "asignarRevision":
                    handleAsignarRevision(request, admin.getIdUsuario());
                    break;
                    
                case "actualizarConfig":
                    // Lógica futura para actualizar la configuración
                    System.out.println("Acción 'actualizarConfig' recibida.");
                    break;
                    
                case "crearUsuario":
                    // Lógica futura para crear un usuario
                    System.out.println("Acción 'crearUsuario' recibida.");
                    break;
                    
                default:
                    System.out.println("Acción POST desconocida: " + accion);
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            // Aquí podrías guardar un mensaje de error en la sesión
            // session.setAttribute("error", "Ocurrió un error al procesar la solicitud.");
        }

        // --- Patrón PRG (Post-Redirect-Get) ---
        // Después de procesar el POST, redirigimos de vuelta al GET.
        // Esto recarga la página (llamando a doGet()) con los datos actualizados.
        response.sendRedirect(request.getContextPath() + "/dashboardAdmin");
    }

    /**
     * Método privado para manejar la lógica de "asignarRevision".
     * Llama al método 'asignarRevisor' de tu TesisDAO.
     */
    private void handleAsignarRevision(HttpServletRequest request, int idAdmin) {
        try {
            // 1. Obtener los IDs del formulario
            int idTesis = Integer.parseInt(request.getParameter("idTesis"));
            int idDocente = Integer.parseInt(request.getParameter("idDocente"));
            
            // 2. El formulario no tiene fecha límite, así que pasamos null.
            java.sql.Date fechaLimite = null; 
            
            // 3. Llamar al método CORRECTO de tu TesisDAO
            tesisDAO.asignarRevisor(idTesis, idDocente, fechaLimite, idAdmin);
            
            // (Opcional) Añadir mensaje de éxito a la sesión para mostrarlo en el JSP
            // request.getSession().setAttribute("exito", "¡Tesis asignada correctamente!");
            
        } catch (NumberFormatException e) {
            System.err.println("Error al parsear IDs en handleAsignarRevision: " + e.getMessage());
            // (Opcional) Guardar error en sesión
            // request.getSession().setAttribute("error", "Error: Los datos enviados no son válidos.");
        } catch (Exception e) {
            System.err.println("Error en handleAsignarRevision: " + e.getMessage());
            e.printStackTrace();
            // (Opcional) Guardar error en sesión
            // request.getSession().setAttribute("error", "Error al asignar la tesis.");
        }
    }
    
    // Aquí puedes añadir más métodos "handle" para las otras acciones
    // private void handleActualizarConfig(HttpServletRequest request, int idAdmin) { ... }
    // private void handleCrearUsuario(HttpServletRequest request) { ... }

}